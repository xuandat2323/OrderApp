import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {FETCH_USER_BY_ID, LOGIN, LOGOUT, REGISTER} from '../ActionType/ActionType';
import {Logout, SignIn, SignUp, getUserById} from '../../API/AuthApi';
import Cookies from 'js-cookie';
import jwt_decode from 'jwt-decode';

// Kiểm tra user đăng nhập
export const isUserLoggedIn = () => {
    const tokenString = Cookies.get('userPayload');
    if (!tokenString) return false;
    const token = JSON.parse(tokenString);
    const jwtToken = token.jwtToken;
    try {
        const decodedToken = jwt_decode(jwtToken);
        const isAdmin = decodedToken?.roles?.includes('ROLE_ADMIN');
        return {
            isLoggedIn: true,
            isAdmin: isAdmin || false
        };
    } catch (err) {
        return {
            isLoggedIn: false,
            isAdmin: false
        };
    }
};

const loginState = isUserLoggedIn();

export const register = createAsyncThunk(REGISTER, async (newUser, {rejectWithValue}) => {
    try {
        const res = await SignUp(newUser);
        if (res?.data) return res;
        return rejectWithValue(res);
    } catch (err) {
        return rejectWithValue(err?.response || err);
    }
});

export const login = createAsyncThunk(LOGIN, async (credentials, {rejectWithValue}) => {
    try {
        const res = await SignIn(credentials);
        console.log('Login response:', res);

        if (res?.data) return res;
        return rejectWithValue(res);
    } catch (err) {
        return rejectWithValue(err?.response || err);
    }
});

export const logout = createAsyncThunk(LOGOUT, async () => {
    await Logout();
    Cookies.remove('userPayload');
    localStorage.clear();
    return null;
});

export const fetchUserById = createAsyncThunk(FETCH_USER_BY_ID, async (id, {rejectWithValue}) => {
    try {
        const user = await getUserById(id);
        return user;
    } catch (err) {
        return rejectWithValue(err?.response || err);
    }
});

// Initial state
const initialState = {
    status: 'idle',
    data: [],
    error: null,
    isLoggedIn: loginState.isLoggedIn,
    isAdmin: loginState.isAdmin
};

const UserSliceReducer = createSlice({
    name: 'user',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(register.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(register.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.data = action.payload.data || [];
                state.error = null;
                state.isLoggedIn = true;
            })
            .addCase(register.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload?.message || 'Register failed';
                state.isLoggedIn = false;
            })

            .addCase(login.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(login.fulfilled, (state, action) => {
                const user = action.payload.data;
                state.status = 'succeeded';
                state.data = user;
                state.error = null;
                state.isLoggedIn = true;
                state.isAdmin = user?.roles?.includes('ROLE_ADMIN') || false;
            })
            .addCase(login.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload?.message || 'Login failed';
                state.isLoggedIn = false;
            })

            .addCase(logout.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(logout.fulfilled, (state) => {
                state.status = 'succeeded';
                state.data = [];
                state.isLoggedIn = false;
                state.isAdmin = false;
                state.error = null;
            })
            .addCase(logout.rejected, (state) => {
                state.status = 'failed';
            })

            .addCase(fetchUserById.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchUserById.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.data = action.payload?.data || [];
                state.error = null;
            })
            .addCase(fetchUserById.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload?.message || 'User fetch failed';
            });
    }
});

export default UserSliceReducer;
