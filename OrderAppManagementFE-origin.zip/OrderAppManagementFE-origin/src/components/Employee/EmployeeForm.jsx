import React, {useState, useEffect} from 'react';

const EmployeeForm = ({onSubmit, initialData, onCancel}) => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        address: '',
        hiredDate: ''
    });

    useEffect(() => {
        if (initialData) setFormData(initialData);
    }, [initialData]);

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData((prev) => ({...prev, [name]: value}));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
        setFormData({firstName: '', lastName: '', email: '', phone: '', address: '', hiredDate: ''});
    };

    return (
        <form onSubmit={handleSubmit} style={{marginBottom: '20px'}}>
            <input name="firstName" value={formData.firstName} onChange={handleChange} placeholder="First Name" required />
            <input name="lastName" value={formData.lastName} onChange={handleChange} placeholder="Last Name" required />
            <input name="email" value={formData.email} onChange={handleChange} placeholder="Email" />
            <input name="phone" value={formData.phone} onChange={handleChange} placeholder="Phone" />
            <input name="address" value={formData.address} onChange={handleChange} placeholder="Address" />
            <input name="hiredDate" value={formData.hiredDate} onChange={handleChange} placeholder="Hired Date" />

            <button type="submit">{initialData ? 'Cập nhật' : 'Thêm mới'}</button>
            {onCancel && (
                <button type="button" onClick={onCancel}>
                    Hủy
                </button>
            )}
        </form>
    );
};

export default EmployeeForm;
