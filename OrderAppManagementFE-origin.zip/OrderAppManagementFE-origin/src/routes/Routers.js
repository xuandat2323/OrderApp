import React from 'react';
import {Routes, Route, Navigate} from 'react-router-dom';
import {ProtectedRoute} from './ProtectedRoute'; // ✅ Đảm bảo đúng đường dẫn

import Home from '../pages/Home';
import Pizzas from '../pages/Pizzas';
import FoodDetails from '../pages/FoodDetails';
import Cart from '../pages/Cart';
import Checkout from '../pages/Checkout';
import Login from '../pages/Login';
import Register from '../pages/Register';
import AdminPage from '../pages/AdminPage';
import OrderPage from '../pages/OrderPage';
import EmployeePage from '../pages/EmployeePage';
import OrderAdminPage from '../pages/OrderAdminPage';

const Routers = () => {
    return (
        <Routes>
            <Route path="/" element={<Navigate to="/home" />} />
            <Route path="/home" element={<Home />} />
            <Route path="/pizzas" element={<Pizzas />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/foods/:id" element={<FoodDetails />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/order" element={<OrderPage />} />
            {/* <Route path="/admin" element={<AdminPage />} /> */}
            <Route
                path="/admin"
                element={
                    // <ProtectedRoute>
                    <AdminPage />
                    // </ProtectedRoute>
                }
            />
            <Route
                path="/admin/employees"
                element={
                    <ProtectedRoute>
                        <EmployeePage />
                    </ProtectedRoute>
                }
            />
            <Route
                path="/admin/orders"
                element={
                    <ProtectedRoute>
                        <OrderAdminPage />
                    </ProtectedRoute>
                }
            />
        </Routes>
    );
};

export default Routers;
