import Layout from "./components/Layout/Layout";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

function App() {
  return <Layout />;
}

export default App;
