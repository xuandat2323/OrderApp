// src/api/authApi.js
import Cookies from 'js-cookie';
import {api} from './api';

// Lấy token từ cookie (nếu cần dùng cho axios trực tiếp)
const tokenString = Cookies.get('userPayload');
let userId;
let accessToken;
if (tokenString) {
    const token = JSON.parse(tokenString);
    userId = token.userId;
    accessToken = token.jwtToken;
}

// ==== AUTH ====
const SignIn = (userData) => api('auth', 'POST', 'login', userData);
const SignUp = (userData) => api('auth', 'POST', 'register', userData);
const Logout = () => api('auth', 'POST', 'logout', '');

// ==== USER ====
const getUserById = (id) => api('auth', 'GET', `user/${id}`, null); // Đảm bảo endpoint đúng
const getAllUsers = () => api('auth', 'GET', 'user/all', null);
const updateUser = (id, userData) => api('auth', 'PUT', `user/${id}`, userData);

// ==== EMPLOYEE ====
const getAllEmployees = () => api('auth', 'GET', 'employee/all', null);
const getEmployeeById = (id) => api('auth', 'GET', `employee/${id}`, null);
const updateEmployee = (id, data) => api('auth', 'PUT', `employee/${id}`, data);

export {SignIn, SignUp, Logout, getUserById};
