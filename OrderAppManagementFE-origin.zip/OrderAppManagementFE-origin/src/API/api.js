// import axios from "axios";

// const axiosClient = axios.create({
//   baseURL: "https://ordermanagementbe-production.up.railway.app/api/v1/",
//   headers: {
//     "content-type": "application/json",
//     "Access-Control-Allow-Origin": true,
//   },
// });

// export const api = (method, endpoint, payload) => {
//   return axiosClient(endpoint, { method: method, data: payload })
//     .then((response) => {
//       return response.data;
//     })
//     .catch((error) => {
//       console.log(error.response.data);
//       return error.response.data;
//     });
// };

// src/api/axiosClient.js
import axios from 'axios';
import Cookies from 'js-cookie';

const SERVICE_BASE_URLS = {
    auth: 'http://localhost:8010/api/auth/',
    // user: 'https://user-service-url/api/v1/',
    // order: 'https://order-service-url/api/v1/',
    product: 'http://localhost:8083/api/v1/',
    cart: 'http://localhost:8084/api/'

    // thêm các service khác tại đây
};

export const api = async (service, method, endpoint, payload = {}) => {
    const baseURL = SERVICE_BASE_URLS[service];

    if (!baseURL) {
        throw new Error(`Service ${service} is not defined in SERVICE_BASE_URLS`);
    }

    let token = null;
    const tokenString = Cookies.get('userPayload');
    if (tokenString) {
        try {
            token = JSON.parse(tokenString).jwtToken;
        } catch (_) {}
    }

    const axiosClient = axios.create({
        baseURL,
        headers: {
            'Content-Type': 'application/json',
            ...(token && {Authorization: `Bearer ${token}`})
        }
    });

    try {
        const response = await axiosClient(endpoint, {
            method,
            data: payload
        });
        return response.data;
    } catch (error) {
        console.error(`[${service}] API Error:`, error?.response?.data || error.message);
        return error?.response?.data || {error: 'Unknown error'};
    }
};
