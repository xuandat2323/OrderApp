import {api} from './api';

const getListProductAPI = () => {
    return api('product', 'GET', 'products', null);
};

const getListFilterdProductAPI = (params) => {
    params = params?.toString();
    let url = `products/paged?${params}`;
    return api('product', 'GET', url, null)
        .then((response) => {
            console.log('API Response:', response);
            return response;
        })
        .catch((error) => {
            throw error;
        });
};

const getProductByIdAPI = (id) => {
    let url = `products/${id}`;
    return api('product', 'GET', url, null);
};

const getProductByCategoryIdAPI = (id) => {
    let url = `product/category/${id}`;
    return api('product', 'GET', url, null);
};

const addProductNewAPI = (ProductNew) => {
    return api('product', 'POST', 'product/', ProductNew);
};

const deleteProductAPI = (id) => {
    let url = `product/${id}`;
    return api('product', 'DELETE', url, null);
};

const updateProductAPI = (productUpdate) => {
    let url = `product/${productUpdate.id}`;
    return api('product', 'PUT', url, productUpdate);
};

const searchProductAPI = (params) => {
    params = params?.toString();
    let url = `products/search?query=${params}`;
    return api('product', 'GET', url, null)
        .then((response) => {
            console.log('API Response:', response);
            return response;
        })
        .catch((error) => {
            throw error;
        });
};

export {getListProductAPI, getListFilterdProductAPI, getProductByIdAPI, getProductByCategoryIdAPI, addProductNewAPI, deleteProductAPI, updateProductAPI, searchProductAPI};
