import {api} from './api';

const addCartwithProduct = ({userId, productId, quantity = 1}) => {
    const params = new URLSearchParams({userId, productId, quantity}).toString();
    return api('cart', 'POST', `cart/add?${params}`);
};

const updateQtyForCart = (cartItemId, quantity) => {
    const params = new URLSearchParams({cartItemId, quantity}).toString();
    return api('cart', 'PUT', `cart/update?${params}`);
};

const decrementProducfromCart = (value) => {
    const productId = value.productId;
    const userId = value.userId;
    const params = new URLSearchParams({userId, productId}).toString();
    return api('cart', 'PUT', `cart/decrementProduct?${params}`);
};

const incrementProducfromCart = (value) => {
    const productId = value.productId;
    const userId = value.userId;
    const params = new URLSearchParams({userId, productId}).toString();
    return api('cart', 'PUT', `cart/decrementProduct?${params}`);
};

const removeProductFromCart = (value) => {
    const productId = value.productId;
    const userId = value.userId;
    const params = new URLSearchParams({userId, productId}).toString();
    return api('cart', 'DELETE', `cart/remove?${params}`);
};

const getCartsByUserId = (userId) => {
    return api('cart', 'GET', `cart/${userId}`);
};

const clearCartByUserId = (userId) => {
    return api('cart', 'DELETE', `cart/clear/${userId}`);
};

const getTotalAmount = (userId) => {
    return api('cart', 'GET', `cart/total/${userId}`);
};

// Nếu có decrementProducfromCart thì cần đảm bảo endpoint hợp lệ

export {addCartwithProduct, updateQtyForCart, removeProductFromCart, getCartsByUserId, clearCartByUserId, getTotalAmount, decrementProducfromCart, incrementProducfromCart};
