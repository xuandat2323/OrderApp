import * as React from 'react';
import {DataGrid} from '@mui/x-data-grid';
import {Container, Button} from '@mui/material';
import {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
// import {actionFetchAllEmployees, actionDeleteEmployee, actionAddEmployee, actionUpdateEmployee, actionFetchEmployeeById} from '../Redux/Reducer/EmployeeSliceReducer';
// import {selectEmployeeList} from '../Redux/Selector/EmployeeSelector';
// import ModalCreateEmployee from '../components/Employee/ModalCreateEmployee';
// import ModalEditEmployee from '../components/Employee/ModalEditEmployee';
import {formActions} from '../Redux/Reducer/FormSliceReducer';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import withAdminPermission from '../components/HOC/withAdminPermission';

function EmployeePage() {
    const dispatch = useDispatch();
    // const {listData: employeeList} = useSelector(selectEmployeeList);
    let employeeList = [];
    employeeList = [
        {
            id: 1,
            firstName: 'Nguyễn',
            lastName: 'An',
            email: 'an.nguyen@example.com',
            phone: '0909123456',
            address: '123 Đường Lê Lợi, Q1',
            hiredDate: '2022-01-15'
        },
        {
            id: 2,
            firstName: 'Trần',
            lastName: 'Bình',
            email: 'binh.tran@example.com',
            phone: '0909234567',
            address: '456 Nguyễn Huệ, Q3',
            hiredDate: '2023-04-10'
        },
        {
            id: 3,
            firstName: 'Lê',
            lastName: 'Cường',
            email: 'cuong.le@example.com',
            phone: '0909345678',
            address: '789 Hai Bà Trưng, Q5',
            hiredDate: '2024-03-20'
        }
    ];
    useEffect(() => {
        // dispatch(actionFetchAllEmployees());
    }, [dispatch]);

    const columns = [
        {field: 'id', headerName: 'ID', width: 80},
        {field: 'firstName', headerName: 'First Name', width: 150},
        {field: 'lastName', headerName: 'Last Name', width: 150},
        {field: 'email', headerName: 'Email', width: 180},
        {field: 'phone', headerName: 'Phone', width: 130},
        {field: 'address', headerName: 'Address', width: 200},
        {field: 'hiredDate', headerName: 'Hired Date', width: 130},
        {
            field: 'delete',
            headerName: 'Delete',
            width: 120,
            renderCell: (params) => {
                const handleDelete = () => {
                    // dispatch(actionDeleteEmployee(params.row.id));
                };
                return (
                    <Button variant="contained" color="error" startIcon={<DeleteIcon />} onClick={handleDelete}>
                        Delete
                    </Button>
                );
            }
        },
        {
            field: 'update',
            headerName: 'Update',
            width: 100,
            renderCell: (params) => {
                const handleEdit = () => {
                    // dispatch(actionFetchEmployeeById(params.row.id));
                    dispatch(formActions.showFormEdit());
                };
                return (
                    <Button variant="contained" color="primary" startIcon={<EditIcon />} onClick={handleEdit}>
                        Edit
                    </Button>
                );
            }
        }
    ];

    const rows = employeeList.map((emp) => ({
        id: emp.id,
        firstName: emp.firstName,
        lastName: emp.lastName,
        email: emp.email,
        phone: emp.phone,
        address: emp.address,
        hiredDate: emp.hiredDate
    }));

    const handleAddNew = () => {
        dispatch(formActions.showFormCreate());
    };

    const handleClose = () => {
        dispatch(formActions.closeForm());
    };

    const handleCreate = (values) => {
        // dispatch(actionAddEmployee(values));
        dispatch(formActions.closeForm());
    };

    const handleUpdate = (values) => {
        // dispatch(actionUpdateEmployee(values));
        dispatch(formActions.closeForm());
    };

    return (
        <Container>
            <h2>Quản lý nhân viên</h2>
            <Button variant="contained" color="success" onClick={handleAddNew}>
                Thêm nhân viên
            </Button>
            {/* <ModalCreateEmployee onHandleClose={handleClose} onHandleCreate={handleCreate} /> */}
            {/* <ModalEditEmployee onH  andleClose={handleClose} onHandleEdit={handleUpdate} /> */}
            <div style={{height: 500, margin: 20}}>
                <DataGrid rows={rows} columns={columns} pageSize={7} checkboxSelection />
            </div>
        </Container>
    );
}

export default withAdminPermission(EmployeePage);
