import React, {useEffect, useState} from 'react';
import {DataGrid} from '@mui/x-data-grid';
import {Container, Typography, Collapse, IconButton} from '@mui/material';
import {ExpandMore, ExpandLess} from '@mui/icons-material';
// import {getAllOrders} from '../api/orderApi'; // giả định bạn có API này

function OrderAdminPage() {
    const [orders, setOrders] = useState([]);
    const [expandedRow, setExpandedRow] = useState(null);

    useEffect(() => {
        const fakeOrders = [
            {
                id: 1,
                customerName: 'Nguyễn Văn A',
                totalQuantity: 3,
                totalAmount: 300000,
                createdAt: '2024-06-01T10:00:00',
                updatedAt: '2024-06-01T11:00:00',
                status: 'PENDING',
                items: [
                    {
                        id: 1,
                        productId: 101,
                        productName: 'Bánh mì',
                        quantity: 1,
                        price: 20000
                    },
                    {
                        id: 2,
                        productId: 102,
                        productName: 'Trà sữa',
                        quantity: 2,
                        price: 140000
                    }
                ]
            },
            {
                id: 2,
                customerName: 'Trần Thị B',
                totalQuantity: 2,
                totalAmount: 180000,
                createdAt: '2024-06-02T14:30:00',
                updatedAt: '2024-06-02T15:00:00',
                status: 'COMPLETED',
                items: [
                    {
                        id: 3,
                        productId: 103,
                        productName: 'Pizza',
                        quantity: 1,
                        price: 120000
                    },
                    {
                        id: 4,
                        productId: 104,
                        productName: 'Coca',
                        quantity: 1,
                        price: 60000
                    }
                ]
            }
        ];
        setOrders(fakeOrders);
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            // const response = await getAllOrders();
            // setOrders(response.data);
        } catch (error) {
            console.error('Lỗi khi tải đơn hàng:', error);
        }
    };

    const columns = [
        {field: 'id', headerName: 'Order ID', width: 100},
        {field: 'userId', headerName: 'User ID', width: 100},
        {field: 'totalQuantity', headerName: 'Tổng SL', width: 100},
        {field: 'totalAmount', headerName: 'Tổng tiền', width: 120},
        {field: 'createdAt', headerName: 'Ngày tạo', width: 180},
        {field: 'status', headerName: 'Trạng thái', width: 130},
        {
            field: 'expand',
            headerName: 'Chi tiết',
            width: 100,
            renderCell: (params) => <IconButton onClick={() => handleToggle(params.row.id)}>{expandedRow === params.row.id ? <ExpandLess /> : <ExpandMore />}</IconButton>
        }
    ];

    const rows = orders.map((order) => ({
        id: order.id,
        userId: order.userId,
        totalQuantity: order.totalQuantity,
        totalAmount: order.totalAmount,
        createdAt: new Date(order.createdAt).toLocaleString(),
        status: order.status
    }));

    const handleToggle = (orderId) => {
        setExpandedRow((prev) => (prev === orderId ? null : orderId));
    };

    return (
        <Container>
            <Typography variant="h5" gutterBottom>
                🧾 Quản lý đơn hàng
            </Typography>

            <div style={{height: 500}}>
                <DataGrid rows={rows} columns={columns} pageSize={5} />
            </div>

            {expandedRow && (
                <Collapse in={!!expandedRow} timeout="auto" unmountOnExit>
                    <Typography variant="h6" style={{marginTop: 20}}>
                        Chi tiết đơn hàng #{expandedRow}
                    </Typography>
                    <div style={{padding: '10px 20px'}}>
                        {orders
                            .find((o) => o.id === expandedRow)
                            ?.items?.map((item) => (
                                <div key={item.id}>
                                    🛒 <b>{item.productName}</b> - SL: {item.quantity} - Giá: {item.price.toLocaleString()}₫
                                </div>
                            ))}
                    </div>
                </Collapse>
            )}
        </Container>
    );
}

export default OrderAdminPage;
