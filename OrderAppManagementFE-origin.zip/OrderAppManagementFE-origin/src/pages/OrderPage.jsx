import React from 'react';
import {useSelector, useDispatch} from 'react-redux';
// import {removeItem, increaseQty, decreaseQty, clearCart} from '../redux/cartSlice';
// import {deleteProductFromCart} from '../store/shopping-cart/cartSliceReducer';
import {addProducttoCart, decrementProductFromCart, deleteProductFromCart} from '../store/shopping-cart/cartSliceReducer';

const OrderPage = () => {
    let cartItems = useSelector((state) => state.data);
    const dispatch = useDispatch();
    cartItems = [];
    const totalAmount = useSelector((state) => state.totalAmount);

    const handleIncrease = (id) => dispatch(addProducttoCart({id}));
    const handleDecrease = (id) => dispatch(decrementProductFromCart({id}));
    const handleRemove = (id) => dispatch(deleteProductFromCart({id}));

    const handleCheckout = () => {
        if (cartItems.length === 0) return alert('Cart is empty!');
        // Thực hiện xác nhận đơn hàng — call API hoặc hiển thị modal
        alert(`Đã đặt đơn thành công. Tổng: ${totalAmount.toLocaleString()}₫`);
        // dispatch(clearCart());
    };

    return (
        <div className="order-page text-center">
            <h2>📦 Xác nhận đơn hàng</h2>
            {cartItems.length === 0 ? (
                <p>Chưa có sản phẩm trong giỏ.</p>
            ) : (
                <>
                    <table>
                        <thead>
                            <tr>
                                <th>Sản phẩm</th>
                                <th>Giá</th>
                                <th>Số lượng</th>
                                <th>Tổng</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {cartItems.map((item) => (
                                <tr key={item.id}>
                                    <td>{item.name}</td>
                                    <td>{item.price.toLocaleString()}₫</td>
                                    <td>
                                        <button onClick={() => handleDecrease(item.id)}>-</button>
                                        <span>{item.quantity}</span>
                                        <button onClick={() => handleIncrease(item.id)}>+</button>
                                    </td>
                                    <td>{(item.price * item.quantity).toLocaleString()}₫</td>
                                    <td>
                                        <button onClick={() => handleRemove(item.id)}>🗑️</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>

                    <div className="order-summary">
                        <h3>Tổng đơn hàng: {totalAmount.toLocaleString()}₫</h3>
                        <button onClick={handleCheckout}>Xác nhận đặt hàng</button>
                        <button>Xóa giỏ</button>
                    </div>
                </>
            )}
        </div>
    );
};

export default OrderPage;
