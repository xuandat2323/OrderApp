-- Tạo tất cả các database cần dùng
CREATE DATABASE IF NOT EXISTS auth_service_db;
CREATE DATABASE IF NOT EXISTS user_service_db;
CREATE DATABASE IF NOT EXISTS product_service_db;
CREATE DATABASE IF NOT EXISTS order_service_db;
CREATE DATABASE IF NOT EXISTS cart_service_db;
CREATE DATABASE IF NOT EXISTS invoice_service_db;
CREATE DATABASE IF NOT EXISTS employee_service_db;
CREATE DATABASE IF NOT EXISTS payment_service_db;

-- Tạo bảng dummy để tránh lỗi empty schema
USE auth_service_db;
CREATE TABLE IF NOT EXISTS dummy_auth (id INT PRIMARY KEY);

USE cart_service_db;
CREATE TABLE IF NOT EXISTS dummy_cart (id INT PRIMARY KEY);

USE employee_service_db;
CREATE TABLE IF NOT EXISTS dummy_employee (id INT PRIMARY KEY);

USE invoice_service_db;
CREATE TABLE IF NOT EXISTS dummy_invoice (id INT PRIMARY KEY);

USE order_service_db;
CREATE TABLE IF NOT EXISTS dummy_order (id INT PRIMARY KEY);

USE payment_service_db;
CREATE TABLE IF NOT EXISTS dummy_payment (id INT PRIMARY KEY);

USE product_service_db;
CREATE TABLE IF NOT EXISTS dummy_product (id INT PRIMARY KEY);

USE user_service_db;
CREATE TABLE IF NOT EXISTS dummy_user (id INT PRIMARY KEY);


USE auth_service_db;

CREATE TABLE IF NOT EXISTS role (
     id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO role (name) VALUES ('ROLE_USER');
INSERT INTO role (name) VALUES ('ROLE_EMPLOYEE');
INSERT INTO role (name) VALUES ('ROLE_ADMIN');
INSERT INTO role (name) VALUES ('ROLE_UNKNOWN');

use product_service_db;

CREATE TABLE IF NOT EXISTS category (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
);

INSERT INTO Category (category_name)
VALUES
    ('Khai vị'),
    ('Món chính'),
    ('Món chiên'),
    ('Món nướng'),
    ('Lẩu'),
    ('Cơm - Mì - Cháo'),
    ('Đồ uống'),
    ('Tráng miệng');

