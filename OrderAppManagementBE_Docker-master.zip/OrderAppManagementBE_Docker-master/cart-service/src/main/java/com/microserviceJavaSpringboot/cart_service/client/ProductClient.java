package com.microserviceJavaSpringboot.cart_service.client;

import com.microserviceJavaSpringboot.cart_service.dto.ProductDTO;
import com.microserviceJavaSpringboot.cart_service.model.ResponseObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "product-service")
public interface ProductClient {

    @GetMapping("/api/v1/products/{id}")
    ResponseObject<ProductDTO> getProductById(@PathVariable("id") Short productId);
}
