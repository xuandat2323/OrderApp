package com.microserviceJavaSpringboot.cart_service.repository;

import com.microserviceJavaSpringboot.cart_service.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {

    List<CartItem> findByCart_Id(Long cartId);

    @Query("SELECT SUM(ci.price) FROM CartItem ci WHERE ci.cart.userId = :userId")
    Optional<Double> sumPriceByUserId(Long userId);

    void deleteAllByCart_Id(Long cartId);
}
