package com.microserviceJavaSpringboot.cart_service.dto;

import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class CartDto {
    private Long id;
    private Short userId;
    private List<CartItemDTO> items;
    private Double totalAmount;
    private Integer totalQuantity;
}
