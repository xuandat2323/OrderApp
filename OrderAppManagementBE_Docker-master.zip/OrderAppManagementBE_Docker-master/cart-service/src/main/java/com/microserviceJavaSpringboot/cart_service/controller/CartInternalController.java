package com.microserviceJavaSpringboot.cart_service.controller;

import com.microserviceJavaSpringboot.cart_service.dto.CartDto;
import com.microserviceJavaSpringboot.cart_service.dto.CartItemDTO;
import com.microserviceJavaSpringboot.cart_service.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/internal/cart")
@RequiredArgsConstructor
public class CartInternalController {

    private final CartService cartService;

    @GetMapping("/{userId}")
    public List<CartDto> getCartByUser(@PathVariable Short userId) {
        return cartService.getCartByUser(userId);
    }

    @DeleteMapping("/{userId}")
    public void clearCartByUser(@PathVariable Short userId) {
        cartService.clearCart(userId);
    }
}
