package com.microserviceJavaSpringboot.cart_service.serviceImpl;

import com.microserviceJavaSpringboot.cart_service.client.ProductClient;
import com.microserviceJavaSpringboot.cart_service.client.UserClient;
import com.microserviceJavaSpringboot.cart_service.dto.CartDto;
import com.microserviceJavaSpringboot.cart_service.dto.CartItemDTO;
import com.microserviceJavaSpringboot.cart_service.dto.ProductDTO;
import com.microserviceJavaSpringboot.cart_service.model.Cart;
import com.microserviceJavaSpringboot.cart_service.model.CartItem;
import com.microserviceJavaSpringboot.cart_service.model.ResponseObject;
import com.microserviceJavaSpringboot.cart_service.repository.CartItemRepository;
import com.microserviceJavaSpringboot.cart_service.repository.CartRepository;
import com.microserviceJavaSpringboot.cart_service.service.CartService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProductClient productClient;
    private final UserClient userClient;

    @Override
    public List<CartDto> getCartByUser(Short userId) {
        validateUser(userId);
        Cart cart = getOrCreateCart(userId);

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            return Collections.emptyList();
        }

        return List.of(mapCartToDto(cart));
    }

    @Transactional
    @Override
    public CartDto addToCart(Short userId, Short productId, Integer quantity) {
        validateUser(userId);
        validateQuantity(quantity);

        ProductDTO product = Optional.ofNullable(productClient.getProductById(productId))
                .map(ResponseObject::getData)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

        Cart cart = getOrCreateCart(userId);
        CartItem item = cart.getItems().stream()
                .filter(i -> i.getProductId().equals(productId))
                .findFirst()
                .map(existingItem -> updateExistingItem(existingItem, quantity, product.getPrice()))
                .orElseGet(() -> createNewItem(cart, productId, quantity, product.getPrice(), product.getName()));

        cartRepository.save(cart);

        return mapCartToDto(cart); // 👈 Trả về toàn bộ cart và tính tổng
    }

    @Transactional
    @Override
    public CartDto removeFromCart(Short userId, Short productId) {
        validateUser(userId);

        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new NoSuchElementException("Cart not found for user: " + userId));

        CartItem item = cart.getItems().stream()
                .filter(i -> i.getProductId().equals(productId))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Product not found in cart: " + productId));

        cart.getItems().remove(item);        // Xoá khỏi danh sách trong Cart
        cartItemRepository.delete(item);     // Xoá bản ghi trong DB

        return mapCartToDto(cart);           // 👈 Trả về giỏ hàng sau khi cập nhật
    }

    @Transactional
    @Override
    public CartDto decrementQuantity(Short userId, Short productId) {
        validateUser(userId);

        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new NoSuchElementException("Cart not found for user: " + userId));

        CartItem item = cart.getItems().stream()
                .filter(i -> i.getProductId().equals(productId))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Product not found in cart: " + productId));

        int currentQuantity = item.getQuantity();

        if (currentQuantity <= 1) {
            cart.getItems().remove(item);             // Xóa khỏi cart
            cartItemRepository.delete(item);          // Xóa khỏi DB
        } else {
            ProductDTO product = Optional.ofNullable(productClient.getProductById(productId))
                    .map(ResponseObject::getData)
                    .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

            item.setQuantity(currentQuantity - 1);
            item.setPrice(product.getPrice() * item.getQuantity());
            cartItemRepository.save(item);
        }

        return mapCartToDto(cart); // 👈 Trả về DTO của toàn bộ giỏ hàng
    }

    @Transactional
    @Override
    public CartDto incrementQuantity(Short userId, Short productId) {
        validateUser(userId);

        ProductDTO product = Optional.ofNullable(productClient.getProductById(productId))
                .map(ResponseObject::getData)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

        Cart cart = getOrCreateCart(userId);

        CartItem item = cart.getItems().stream()
                .filter(i -> i.getProductId().equals(productId))
                .findFirst()
                .map(existingItem -> updateExistingItem(existingItem, 1, product.getPrice())) // 👈 tăng 1 đơn vị
                .orElseGet(() -> createNewItem(cart, productId, 1, product.getPrice(), product.getName())); // nếu chưa có thì thêm mới

        cartRepository.save(cart);

        return mapCartToDto(cart); // 👈 Trả về toàn bộ cart
    }

    @Transactional
    @Override
    public void updateQuantity(Long cartItemId, Integer newQuantity) {
        validateQuantity(newQuantity);
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new NoSuchElementException("Cart item not found: " + cartItemId));

        ProductDTO product = Optional.ofNullable(productClient.getProductById(item.getProductId()))
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + item.getProductId())).getData();

        item.setQuantity(newQuantity);
        item.setPrice(product.getPrice() * newQuantity);
        cartItemRepository.save(item);
    }

    @Transactional
    @Override
    public void clearCart(Short userId) {
        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new NoSuchElementException("Cart not found for user: " + userId));

        cartItemRepository.deleteAll(cart.getItems());
        cart.getItems().clear();
        cartRepository.save(cart);
    }

    @Transactional(readOnly = true)
    @Override
    public Double getTotalAmount(Long userId) {
        return cartItemRepository.sumPriceByUserId(userId).orElse(0.0);
    }

    // ------------------ Helper Methods ------------------

    private void validateUser(Short userId) {
        if (userId == null || userId <= 0) {
            throw new IllegalArgumentException("Invalid user ID");
        }
        if (userClient.getUserById(userId) == null) {
            throw new NoSuchElementException("User not found: " + userId);
        }
    }

    private void validateQuantity(Integer quantity) {
        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero");
        }
    }

    private Cart getOrCreateCart(Short userId) {
        return cartRepository.findByUserId(userId)
                .map(cart -> {
                    if (cart.getItems() == null) {
                        cart.setItems(new ArrayList<>());
                    }
                    return cart;
                })
                .orElseGet(() -> cartRepository.save(
                        Cart.builder()
                                .userId(userId)
                                .items(new ArrayList<>())
                                .build()));
    }

    private CartItem updateExistingItem(CartItem item, int additionalQuantity, double unitPrice) {
        int newQuantity = item.getQuantity() + additionalQuantity;
        item.setQuantity(newQuantity);
        item.setPrice(unitPrice * newQuantity);
        return item;
    }

    private CartItem createNewItem(Cart cart, Short productId, int quantity, double unitPrice, String productName) {
        CartItem newItem = CartItem.builder()
                .cart(cart)
                .productId(productId)
                .productName(productName)
                .quantity(quantity)
                .price(unitPrice * quantity)
                .build();

        cart.getItems().add(newItem);
        cartItemRepository.save(newItem);
        return newItem;
    }


    private CartDto mapToDTO(CartItem item) {
        return CartDto.builder()
                .id(item.getCart().getId())
                .userId(item.getCart().getUserId())
                .items(Collections.singletonList(CartItemDTO.builder()
                        .Id(item.getId())
                        .productId(item.getProductId())
                        .productName(item.getProductName())
                        .quantity(item.getQuantity())
                        .price(item.getPrice())
                        .build()))
                .totalAmount(item.getPrice())
                .totalQuantity(item.getQuantity())
                .build();
    }

    private CartDto mapCartToDto(Cart cart) {
        List<CartItemDTO> itemDTOs = cart.getItems().stream().map(item -> CartItemDTO.builder()
                .Id(item.getId())
                .productId(item.getProductId())
                .productName(item.getProductName())
                .quantity(item.getQuantity())
                .price(item.getPrice())
                .build()).collect(Collectors.toList());

        double totalAmount = cart.getItems().stream()
                .mapToDouble(CartItem::getPrice)
                .sum();

        int totalQuantity = cart.getItems().stream()
                .mapToInt(CartItem::getQuantity)
                .sum();

        return CartDto.builder()
                .id(cart.getId())
                .userId(cart.getUserId())
                .items(itemDTOs)
                .totalAmount(totalAmount)
                .totalQuantity(totalQuantity)
                .build();
    }


}
