package com.microserviceJavaSpringboot.cart_service.kafka;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microserviceJavaSpringboot.cart_service.service.CartService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class CartPaymentConsumer {

    private final CartService cartService;
    private final ObjectMapper mapper = new ObjectMapper();

    /**
     * ✅ Lắng nghe event thanh toán từ topic "payment-events"
     * Khi thanh toán thành công → xóa giỏ hàng user đó
     */
    @KafkaListener(topics = "payment-events", groupId = "cart-service-group")
    public void handlePaymentEvent(String message) {
        try {
            JsonNode json = mapper.readTree(message);
            String status = json.get("status").asText();
            String userId = json.get("userId").asText();
            String orderId = json.get("orderId").asText();
            String gateway = json.has("gateway") ? json.get("gateway").asText() : "unknown";
            Short userIdShort = Short.parseShort(userId);

            log.info("Nhận PaymentEvent từ Kafka: orderId={}, status={}, userId={}, gateway={}",
                    orderId, status, userId, gateway);

            if ("SUCCESS".equalsIgnoreCase(status)) {
                cartService.clearCart(userIdShort);
                log.info("Đã xóa giỏ hàng cho userId={} sau khi thanh toán thành công.", userId);
            } else {
                log.warn("⚠Thanh toán thất bại cho orderId={}, không xóa giỏ hàng.", orderId);
            }

        } catch (Exception e) {
            log.error("Lỗi khi xử lý PaymentEvent trong cart-service: {}", e.getMessage(), e);
        }
    }
}
