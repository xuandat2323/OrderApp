package com.microserviceJavaSpringboot.cart_service.service;

import com.microserviceJavaSpringboot.cart_service.dto.CartDto;
import com.microserviceJavaSpringboot.cart_service.model.PaginationResponse;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

//public interface CartService {
//    List<CartDto> getAggregatedCartByUserId(Short userId);
//    PaginationResponse<CartDto> getCartByUserId(Short userId, int pageNo, int pageSize);
//    List<CartDto> addCartByUserIdAndProductId(Short productId, Short userId, Integer qty, Double price) throws Exception;
//    List<CartDto> removeProductFromCartByUserIdAndProductId(Short cartId, Short productId, Short userId, Double price) throws Exception;
//    void updateQuantityByCartId(Short cartId, Integer quantity, Double price) throws Exception;
//    List<CartDto> removeCartByUserId(Short cartId, Short userId);
//    List<CartDto> removeAllCartByUserId(Short userId);
//    Boolean checkTotalAmountAgainstCart(Double totalAmount, Short userId);
////    List<CheckoutCartDTO> getAllCheckoutByUserId(Short userId);
////    List<CheckoutCartDTO> saveProductsForCheckout(List<CheckoutCartDTO> checkoutCarts) throws Exception;
//    Double getTotalAmountForUser(Short userId);
//    Integer getTotalQuantityForUser(Short userId);
//}

public interface CartService {

    List<CartDto> getCartByUser(Short userId);

    @Transactional
    CartDto addToCart(Short userId, Short productId, Integer quantity);

    @Transactional
    CartDto removeFromCart(Short userId, Short productId);

    @Transactional
    CartDto decrementQuantity(Short userId, Short productId);

    @Transactional
    CartDto incrementQuantity(Short userId, Short productId);

    @Transactional
    void updateQuantity(Long cartItemId, Integer newQuantity);

    @Transactional
    void clearCart(Short userId);

    @Transactional(readOnly = true)
    Double getTotalAmount(Long userId);
}
