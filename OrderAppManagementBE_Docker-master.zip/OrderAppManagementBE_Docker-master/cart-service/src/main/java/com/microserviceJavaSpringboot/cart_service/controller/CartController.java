package com.microserviceJavaSpringboot.cart_service.controller;

import com.microserviceJavaSpringboot.cart_service.dto.CartDto;
import com.microserviceJavaSpringboot.cart_service.model.ResponseObject;
import com.microserviceJavaSpringboot.cart_service.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;

    @GetMapping("/{userId}")
    public ResponseEntity<List<CartDto>> getCartByUser(@PathVariable Short userId) {
        List<CartDto> cartItems = cartService.getCartByUser(userId);
        return ResponseEntity.ok(cartItems);
    }

    @PostMapping("/add")
    public ResponseEntity<CartDto> addToCart(
            @RequestParam Short userId,
            @RequestParam Short productId,
            @RequestParam Integer quantity) {
        CartDto addedItem = cartService.addToCart(userId, productId, quantity);
        return ResponseEntity.ok(addedItem);
    }

    @PutMapping("/decrementProduct")
    public ResponseEntity<CartDto> decrementProduct(
            @RequestParam("userId") Short userId,
            @RequestParam("productId") Short productId) {
        CartDto updatedItem= cartService.decrementQuantity(userId, productId);
        return ResponseEntity.ok(updatedItem);
    }

//    @PutMapping("/incrementProduct")
//    public ResponseEntity<?> incrementProduct(
//            @RequestParam Short userId,
//            @RequestParam Short productId) {
//        CartDto cartDto = cartService.incrementQuantity(userId, productId);
//        return ResponseEntity.ok(new ResponseObject("Success", "Incremented quantity", cartDto));
//    }


    @PutMapping("/update")
    public ResponseEntity<String> updateQuantity(
            @RequestParam Long cartItemId,
            @RequestParam Integer quantity) {
        cartService.updateQuantity(cartItemId, quantity);
        return ResponseEntity.ok("Quantity updated successfully.");
    }

    @DeleteMapping("/removeProduct")
    public ResponseEntity<CartDto> removeProductFromCart(
            @RequestParam Short userId,
            @RequestParam Short productId) {
        CartDto updatedItem = cartService.removeFromCart(userId, productId);
        return ResponseEntity.ok(updatedItem);
    }


    @DeleteMapping("/clear/{userId}")
    public ResponseEntity<String> clearCart(@PathVariable Short userId) {
        cartService.clearCart(userId);
        return ResponseEntity.ok("Cart cleared successfully.");
    }

    @GetMapping("/total/{userId}")
    public ResponseEntity<Double> getTotalAmount(@PathVariable Long userId) {
        Double totalAmount = cartService.getTotalAmount(userId);
        return ResponseEntity.ok(totalAmount);
    }
}
