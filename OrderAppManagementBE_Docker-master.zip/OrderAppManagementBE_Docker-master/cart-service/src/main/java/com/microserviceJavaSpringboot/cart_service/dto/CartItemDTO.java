package com.microserviceJavaSpringboot.cart_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.security.PrivateKey;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CartItemDTO {
    private Long Id;
    private Short productId;
    private String productName;
    private Integer quantity;
    private Double price;
}
