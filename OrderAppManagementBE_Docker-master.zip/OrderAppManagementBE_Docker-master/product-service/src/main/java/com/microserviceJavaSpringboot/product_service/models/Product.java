package com.microserviceJavaSpringboot.product_service.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.microserviceJavaSpringboot.product_service.models.Category;
import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "Menu")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ProductId", nullable = false, unique = true)
    private Short id;

    @Column(name = "ProductName", length = 50, nullable = false, unique = true)
    private String name;

    @Column(name = "ProductCountry", length = 50, nullable = false)
    private String country;

    @Column(name = "ProductImg", length = 300)
    private String img;

    @Column(name = "Price", nullable = false, precision = 10)
    private Double price;

    @Column(name = "Rate")
    private Short rate;

    @Column(name ="Quantity")
    private Integer quantity;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CategoryId")
    private Category category;
}
