package com.microserviceJavaSpringboot.product_service.form;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductFormForUpdating {
    private String name;
    private String country;
    private String img;
    private Double price;
    private short rate;
    private short categoryId;
    private Integer quantity;


}
