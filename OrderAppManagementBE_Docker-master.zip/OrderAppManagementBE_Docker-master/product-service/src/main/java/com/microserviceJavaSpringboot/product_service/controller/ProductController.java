package com.microserviceJavaSpringboot.product_service.controller;

import com.microserviceJavaSpringboot.product_service.dto.ProductDTO;
import com.microserviceJavaSpringboot.product_service.form.ProductFormForCreating;
import com.microserviceJavaSpringboot.product_service.form.ProductFormForUpdating;
import com.microserviceJavaSpringboot.product_service.mapper.ProductMapper;
import com.microserviceJavaSpringboot.product_service.models.PaginationResponse;
import com.microserviceJavaSpringboot.product_service.models.Product;
import com.microserviceJavaSpringboot.product_service.models.ResponseObject;
import com.microserviceJavaSpringboot.product_service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/products")
@CrossOrigin(origins = "*")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductMapper productMapper;

    @PostMapping
    public ResponseEntity<ResponseObject> createNewProduct(@RequestBody ProductFormForCreating form) {
        try {
            ProductDTO product = productService.createNewProduct(form);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(new ResponseObject("ok", "Created product successfully", product));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseObject("failed", "Cannot create product: " + e.getMessage(), null));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot create product", e.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<ResponseObject> getAllProducts(
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        try {
            List<ProductDTO> products = productService.getAllProducts(pageNo, pageSize, sortBy, sortDir);
            return ResponseEntity.ok(new ResponseObject("ok", "Fetched products successfully", products));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot fetch products", e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<ResponseObject> getProductById(@PathVariable short id) {
        try {
            ProductDTO product = productService.getProductById(id);
            return ResponseEntity.ok(new ResponseObject("ok", "Fetched product successfully", product));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseObject("failed", "Product not found", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot fetch product", e.getMessage()));
        }
    }

    @GetMapping("/category/{categoryId}")
    public ResponseEntity<ResponseObject> getProductsByCategoryId(
            @PathVariable short categoryId,
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize) {
        try {
            List<ProductDTO> products = productService.getProductsByCategoryId(categoryId, pageNo, pageSize);
            return ResponseEntity.ok(new ResponseObject("ok", "Fetched products by category successfully", products));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseObject("failed", "Category not found", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot fetch products by category", e.getMessage()));
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<ResponseObject> updateProduct(
            @PathVariable short id,
            @RequestBody ProductFormForUpdating form) {
        try {
            ProductDTO updatedProduct = productService.updateProduct(id, form);
            return ResponseEntity.ok(new ResponseObject("ok", "Updated product successfully", updatedProduct));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseObject("failed", "Cannot update product: " + e.getMessage(), null));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot update product", e.getMessage()));
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ResponseObject> deleteProduct(@PathVariable short id) {
        try {
            productService.deleteProductById(id);
            return ResponseEntity.ok(new ResponseObject("ok", "Deleted product successfully", null));
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ResponseObject("failed", "Product not found", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot delete product", e.getMessage()));
        }
    }

    @GetMapping("/paged")
    public ResponseEntity<ResponseObject> getPagedProducts(
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "5") int pageSize,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        try {
            Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name())
                    ? Sort.by(sortBy).ascending()
                    : Sort.by(sortBy).descending();
            Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

            List<ProductDTO> products = productService.getAllProducts(pageNo, pageSize, sortBy, sortDir);

            long totalElements = productService.getAllProducts(0, Integer.MAX_VALUE, sortBy, sortDir).size();
            int totalPages = (int) Math.ceil((double) totalElements / pageSize);

            PaginationResponse<ProductDTO> response = PaginationResponse.<ProductDTO>builder()
                    .content(products)
                    .pageNo(pageNo)
                    .pageSize(pageSize)
                    .totalElements(totalElements)
                    .totalPages(totalPages)
                    .last(pageNo >= totalPages - 1)
                    .build();

            return ResponseEntity.ok(new ResponseObject("ok", "Fetched paged products successfully", response));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot fetch paged products", e.getMessage()));
        }
    }

    @GetMapping("/search")
    public ResponseEntity<ResponseObject> searchProducts(
            @RequestParam("query") String keyword,
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize) {
        try {
            List<ProductDTO> products = productService.searchProducts(keyword, pageNo, pageSize);
            return ResponseEntity.ok(new ResponseObject("ok", "Search completed successfully", products));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ResponseObject("failed", "Cannot search products", e.getMessage()));
        }
    }


    // --- PRIVATE HELPER ---

//    private ProductDTO mapToDto(Product product) {
//        return ProductDTO.builder()
//                .id(product.getId())
//                .name(product.getName())
//                .country(product.getCountry())
//                .img(product.getImg())
//                .price(product.getPrice())
//                .rate(product.getRate())
//                .categoryName(product.getCategory().getName())
//                .build();
//    }
}

