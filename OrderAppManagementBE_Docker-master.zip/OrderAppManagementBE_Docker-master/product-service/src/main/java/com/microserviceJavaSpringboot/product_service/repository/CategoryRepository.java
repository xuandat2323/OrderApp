package com.microserviceJavaSpringboot.product_service.repository;

import com.microserviceJavaSpringboot.product_service.models.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category,Short> {
}
