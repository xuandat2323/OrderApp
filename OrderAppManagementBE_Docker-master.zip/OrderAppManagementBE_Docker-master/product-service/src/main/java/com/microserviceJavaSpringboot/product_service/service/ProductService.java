package com.microserviceJavaSpringboot.product_service.service;

import com.microserviceJavaSpringboot.product_service.dto.ProductDTO;
import com.microserviceJavaSpringboot.product_service.form.ProductFormForCreating;
import com.microserviceJavaSpringboot.product_service.form.ProductFormForUpdating;
import com.microserviceJavaSpringboot.product_service.mapper.ProductMapper;
import com.microserviceJavaSpringboot.product_service.models.Category;
import com.microserviceJavaSpringboot.product_service.models.Product;
import com.microserviceJavaSpringboot.product_service.repository.CategoryRepository;
import com.microserviceJavaSpringboot.product_service.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final ProductMapper productMapper;

    public ProductDTO createNewProduct(ProductFormForCreating productForm) {
        log.info("Creating new product with name: {}", productForm.getName());

        Category category = categoryRepository.findById(productForm.getCategoryId())
                .orElseThrow(() -> new NoSuchElementException("Category not found with id: " + productForm.getCategoryId()));

        Product product = Product.builder()
                .name(productForm.getName())
                .country(productForm.getCountry())
                .img(productForm.getImg())
                .price(productForm.getPrice())
                .rate(productForm.getRate())
                .quantity(productForm.getQuantity())
                .category(category)
                .build();

        Product savedProduct = productRepository.save(product);
        return productMapper.toDTO(savedProduct);
    }

    public List<ProductDTO> getAllProducts(int pageNo, int pageSize, String sortBy, String sortDir) {
        log.info("Fetching all products - page: {}, size: {}, sortBy: {}, sortDir: {}",
                pageNo, pageSize, sortBy, sortDir);

        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name())
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
        Page<Product> productsPage = productRepository.findAll(pageable);

        return productsPage.getContent()
                .stream()
                .map(productMapper::toDTO)
                .collect(Collectors.toList());
    }

    public ProductDTO getProductById(short id) {
        log.info("Fetching product with id: {}", id);

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Product not found with id: " + id));

        return productMapper.toDTO(product);
    }

    public List<ProductDTO> searchProducts(String keyword, int pageNo, int pageSize) {
        log.info("Searching products with keyword: {}", keyword);

        Pageable pageable = PageRequest.of(pageNo, pageSize);
            Page<Product> productsPage = productRepository.findByNameContainingIgnoreCase(keyword, pageable);

        return productsPage.getContent()
                .stream()
                .map(productMapper::toDTO)
                .collect(Collectors.toList());
    }

    public List<ProductDTO> getProductsByCategoryId(short categoryId, int pageNo, int pageSize) {
        log.info("Fetching products for category id: {}", categoryId);

        if (!categoryRepository.existsById(categoryId)) {
            throw new NoSuchElementException("Category not found with id: " + categoryId);
        }

        Pageable pageable = PageRequest.of(pageNo, pageSize);
        Page<Product> productsPage = productRepository.findByCategoryId(categoryId, pageable);

        return productsPage.getContent()
                .stream()
                .map(productMapper::toDTO)
                .collect(Collectors.toList());
    }

    public ProductDTO updateProduct(short id, ProductFormForUpdating productForm) {
        log.info("Updating product with id: {}", id);

        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Product not found with id: " + id));

        Category category = categoryRepository.findById(productForm.getCategoryId())
                .orElseThrow(() -> new NoSuchElementException("Category not found with id: " + productForm.getCategoryId()));

        product.setName(productForm.getName());
        product.setCountry(productForm.getCountry());
        product.setImg(productForm.getImg());
        product.setPrice(productForm.getPrice());
        product.setRate(productForm.getRate());
        product.setQuantity(productForm.getQuantity());
        product.setCategory(category);

        Product updatedProduct = productRepository.save(product);
        return productMapper.toDTO(updatedProduct);
    }

    public void deleteProductById(short productId) {
        log.info("Deleting product with id: {}", productId);

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new NoSuchElementException("Product not found with id: " + productId));

        productRepository.delete(product);
    }
}