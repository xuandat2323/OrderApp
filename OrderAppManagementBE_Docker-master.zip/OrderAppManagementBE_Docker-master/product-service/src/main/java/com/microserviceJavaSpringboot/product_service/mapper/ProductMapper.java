package com.microserviceJavaSpringboot.product_service.mapper;

import com.microserviceJavaSpringboot.product_service.dto.ProductDTO;
import com.microserviceJavaSpringboot.product_service.models.Product;
import org.springframework.stereotype.Component;

@Component
public class ProductMapper {
    public ProductDTO toDTO(Product product) {
        if (product == null) return null;

        return ProductDTO.builder()
                .id(product.getId())
                .name(product.getName())
                .country(product.getCountry())
                .img(product.getImg())
                .price(product.getPrice())
                .rate(product.getRate())
                .quantity(product.getQuantity())
                .categoryName(
                        product.getCategory() != null ? product.getCategory().getName() : null
                )
                .build();
    }
}
