package com.microserviceJavaSpringboot.product_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductDTO {
    private Short id;
    private String name;
    private String country;
    private String img;
    private Double price;
    private Short rate;
    private String categoryName;
    private Integer quantity;
}