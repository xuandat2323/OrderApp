package com.microserviceJavaSpringboot.product_service.service;

public class CategoryService {
}
