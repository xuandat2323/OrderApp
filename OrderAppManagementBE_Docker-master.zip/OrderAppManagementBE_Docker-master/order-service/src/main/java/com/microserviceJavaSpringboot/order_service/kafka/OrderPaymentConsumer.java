package com.microserviceJavaSpringboot.order_service.kafka;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microserviceJavaSpringboot.order_service.enums.OrderStatus;
import com.microserviceJavaSpringboot.order_service.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderPaymentConsumer {

    private final OrderService orderService;

    @KafkaListener(topics = "payment-events", groupId = "order-service-group")
    public void consumePaymentEvent(String message) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode json = mapper.readTree(message);

            Long orderId = json.get("orderId").asLong();
            String status = json.get("status").asText();
            String msg = json.get("message").asText();

            if ("SUCCESS".equals(status)) {
                orderService.updateOrderStatus(orderId, OrderStatus.PAID);
                log.info("✅ Order {} updated to PAID (message={})", orderId, msg);
            } else if ("FAILED".equals(status)) {
                orderService.updateOrderStatus(orderId, OrderStatus.CANCELLED);
                log.warn("❌ Order {} updated to FAILED (reason={})", orderId, msg);
            }

        } catch (Exception e) {
            log.error("Error processing payment event: {}", e.getMessage(), e);
        }
    }
}
