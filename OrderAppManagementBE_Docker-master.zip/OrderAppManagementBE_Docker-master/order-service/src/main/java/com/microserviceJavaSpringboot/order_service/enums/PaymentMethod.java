package com.microserviceJavaSpringboot.order_service.enums;

public enum PaymentMethod {
    MOMO,
    VNPAY
}
