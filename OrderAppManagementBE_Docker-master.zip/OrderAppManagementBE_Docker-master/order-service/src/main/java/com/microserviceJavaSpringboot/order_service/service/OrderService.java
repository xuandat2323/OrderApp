    package com.microserviceJavaSpringboot.order_service.service;

    import com.microserviceJavaSpringboot.cart_service.dto.CartItemDTO;
    import com.microserviceJavaSpringboot.order_service.client.CartClient;
    import com.microserviceJavaSpringboot.order_service.client.PaymentClient;
    import com.microserviceJavaSpringboot.order_service.client.UserClient;
    import com.microserviceJavaSpringboot.order_service.dto.*;
    import com.microserviceJavaSpringboot.order_service.enums.OrderStatus;
    import com.microserviceJavaSpringboot.order_service.enums.PaymentMethod;
    import com.microserviceJavaSpringboot.order_service.models.Order;
    import com.microserviceJavaSpringboot.order_service.models.OrderHistory;
    import com.microserviceJavaSpringboot.order_service.models.OrderItem;
    import com.microserviceJavaSpringboot.order_service.repository.OrderHistoryRepository;
    import com.microserviceJavaSpringboot.order_service.repository.OrderItemRepository;
    import com.microserviceJavaSpringboot.order_service.repository.OrderRepository;
    import jakarta.transaction.Transactional;
    import lombok.RequiredArgsConstructor;
    import lombok.extern.slf4j.Slf4j;
    import org.springframework.http.ResponseEntity;
    import org.springframework.stereotype.Service;
    import org.springframework.web.client.RestTemplate;
    import org.springframework.web.util.UriComponentsBuilder;

    import java.time.LocalDateTime;
    import java.util.HashMap;
    import java.util.List;
    import java.util.Map;
    import java.util.NoSuchElementException;
    import java.util.stream.Collectors;

    @Service
    @RequiredArgsConstructor
    @Slf4j
    public class OrderService {

        private final OrderRepository orderRepository;
        private final OrderItemRepository orderItemRepository;
        private final OrderHistoryRepository orderHistoryRepository;
        private final UserClient userClient;
        private final PaymentClient paymentClient;
        private final CartClient cartClient;


        public List<OrderResponse> getAllOrders() {
            return orderRepository.findAll().stream()
                    .map(this::mapToOrderResponse)
                    .collect(Collectors.toList());
        }

        @Transactional
        public OrderResponse createOrder(OrderRequest request) {
            validateUser(request.getUserId());

            List<CartDTO> carts = cartClient.getCartByUserId(request.getUserId());
            if (carts.isEmpty() || carts.get(0).getItems().isEmpty()) {
                throw new IllegalArgumentException("Cart is empty for user: " + request.getUserId());
            }

            System.out.println("🟢 Retrieved Cart = " + carts);
            System.out.println("🟢 Retrieved Cart = " + carts.get(0));

            List<CartItemDTO> cartItems = carts.get(0).getItems();

            Order order = Order.builder()
                    .userId(request.getUserId())
                    .createdAt(LocalDateTime.now())
                    .status(OrderStatus.PENDING)
                    .build();

            System.out.println("🟢 Created Order = {}" +  order);

            List<OrderItem> orderItems = mapCartItemsToOrderItems(cartItems, order);
            order.setItems(orderItems);

            System.out.println("🟢 Mapped Order Items = {}" + orderItems);

            double totalAmount = orderItems.stream()
                    .mapToDouble(item -> item.getPrice() * item.getQuantity())
                    .sum();

            int totalQuantity = orderItems.stream()
                    .mapToInt(OrderItem::getQuantity)
                    .sum();

            order.setTotalAmount(totalAmount);
            order.setTotalQuantity(totalQuantity);

            Order savedOrder = orderRepository.save(order);
//            saveOrderHistory(savedOrder, OrderStatus.PENDING);

            PaymentRequestDTO paymentRequest = new PaymentRequestDTO(savedOrder.getId(), totalAmount, savedOrder.getUserId());

            System.out.println("PaymentRequest" + paymentRequest);

            try {
                PaymentResponse paymentResponse;

                switch (request.getPaymentMethod()) {
                    case VNPAY -> paymentResponse = paymentClient.createVNPayPayment(paymentRequest);
                    case MOMO -> paymentResponse = paymentClient.createMomoPayment(paymentRequest);
                    default -> throw new IllegalArgumentException("Unsupported payment method: " + request.getPaymentMethod());
                }
                System.out.println("🟢 PaymentResponse raw = {}" + paymentResponse);

                savedOrder.setPaymentUrl(paymentResponse.getPayUrl());
                savedOrder.setPaymentMethod(request.getPaymentMethod());
                savedOrder.setStatus(OrderStatus.PENDING);
                savedOrder = orderRepository.save(savedOrder);
                System.out.println("🟢 Saved Order with Payment URL = {}" + savedOrder.getPaymentUrl());
                saveOrderHistory(savedOrder, OrderStatus.PENDING);

            } catch (Exception ex) {
                log.error("Payment service error: {}", ex.getMessage(), ex);
                throw new RuntimeException("Failed to initiate payment. Please try again later.");
            }

            // cartClient.clearCartByUserId(request.getUserId());

            return mapToOrderResponse(savedOrder);
        }


        public OrderResponse getOrderById(Long orderId) {
            Order order = orderRepository.findById(orderId)
                    .orElseThrow(() -> new NoSuchElementException("Order not found with id: " + orderId));
            return mapToOrderResponse(order);
        }

        public List<OrderResponse> getOrdersByUserId(Short userId) {
            return orderRepository.findByUserId(userId).stream()
                    .map(this::mapToOrderResponse)
                    .collect(Collectors.toList());
        }

        @Transactional
        public OrderResponse updateOrderStatus(Long orderId, OrderStatus status) {
            Order order = orderRepository.findById(orderId)
                    .orElseThrow(() -> new NoSuchElementException("Order not found with id: " + orderId));

            order.setStatus(status);
            saveOrderHistory(order, status);

            return mapToOrderResponse(orderRepository.save(order));
        }

        @Transactional
        public void deleteOrder(Long orderId) {
            Order order = orderRepository.findById(orderId)
                    .orElseThrow(() -> new NoSuchElementException("Order not found with id: " + orderId));
            orderItemRepository.deleteAll(order.getItems());
            orderRepository.delete(order);
        }

        public Map<String, Object> getOrderStatistics() {
            List<Order> allOrders = orderRepository.findAll();
            long total = allOrders.size();
            long pending = allOrders.stream().filter(o -> o.getStatus() == OrderStatus.PENDING).count();
            long shipped = allOrders.stream().filter(o -> o.getStatus() == OrderStatus.SHIPPED).count();
            long canceled = allOrders.stream().filter(o -> o.getStatus() == OrderStatus.CANCELLED).count();
            double totalRevenue = allOrders.stream().mapToDouble(Order::getTotalAmount).sum();

            Map<String, Object> stats = new HashMap<>();
            stats.put("totalOrders", total);
            stats.put("pendingOrders", pending);
            stats.put("shippedOrders", shipped);
            stats.put("canceledOrders", canceled);
            stats.put("totalRevenue", totalRevenue);
            return stats;
        }

        public List<OrderHistory> getOrderHistory(Long orderId) {
            return orderHistoryRepository.findByOrderId(orderId);
        }


        private void validateUser(Short userId) {
            if (userId == null || userId <= 0) {
                throw new IllegalArgumentException("Invalid user ID");
            }

            UserDTO user = userClient.getUserById(userId);
            if (user == null) {
                throw new NoSuchElementException("User not found: " + userId);
            }
        }

        private void saveOrderHistory(Order order, OrderStatus status) {
            OrderHistory history = OrderHistory.builder()
                    .order(order)
                    .status(status)
                    .createdAt(LocalDateTime.now())
                    .build();

            orderHistoryRepository.save(history);
        }

        private List<OrderItem> mapCartItemsToOrderItems(List<CartItemDTO> cartItems, Order order) {
            return cartItems.stream()
                    .map(cartItem -> OrderItem.builder()
                            .order(order)
                            .productId(cartItem.getProductId())
                            .productName(cartItem.getProductName())
                            .quantity(cartItem.getQuantity())
                            .price(cartItem.getPrice())
                            .build())
                    .collect(Collectors.toList());
        }

        private OrderResponse mapToOrderResponse(Order order) {
            return OrderResponse.builder()
                    .orderId(order.getId())
                    .userId(order.getUserId())
                    .orderDate(order.getCreatedAt())
                    .status(String.valueOf(order.getStatus()))
                    .totalAmount(order.getTotalAmount())
                    .paymentMethod(order.getPaymentMethod().name())
                    .paymentUrl(order.getPaymentUrl())
                    .items(order.getItems().stream()
                            .map(item -> OrderItemDTO.builder()
                                    .id(item.getId())
                                    .productId(item.getProductId())
                                    .productName(item.getProductName())
                                    .quantity(item.getQuantity())
                                    .price(item.getPrice())
                                    .build())
                            .collect(Collectors.toList()))
                    .build();
        }
    }