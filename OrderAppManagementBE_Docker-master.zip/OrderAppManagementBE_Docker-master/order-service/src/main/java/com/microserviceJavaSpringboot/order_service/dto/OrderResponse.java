package com.microserviceJavaSpringboot.order_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderResponse {
    private Long orderId;
    private Short userId;
    private LocalDateTime orderDate;
    private String status;

    private List<OrderItemDTO> items;
    private Double totalAmount;
    private String paymentUrl;
    private String paymentMethod;
}
