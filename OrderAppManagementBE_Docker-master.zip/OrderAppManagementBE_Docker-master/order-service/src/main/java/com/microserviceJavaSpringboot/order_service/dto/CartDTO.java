package com.microserviceJavaSpringboot.order_service.dto;

import com.microserviceJavaSpringboot.cart_service.dto.CartItemDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CartDTO {
    private Long id;
    private Short userId;
    private List<CartItemDTO> items;
    private Double totalAmount;
    private Integer totalQuantity;
}