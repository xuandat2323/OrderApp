package com.microserviceJavaSpringboot.order_service.dto;

import com.microserviceJavaSpringboot.cart_service.dto.CartItemDTO;
import com.microserviceJavaSpringboot.order_service.enums.PaymentMethod;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderRequest {
    private Short userId;
    private PaymentMethod paymentMethod;
}

