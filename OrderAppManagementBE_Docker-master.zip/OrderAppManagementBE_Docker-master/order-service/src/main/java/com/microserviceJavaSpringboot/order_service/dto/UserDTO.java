package com.microserviceJavaSpringboot.order_service.dto;

public class UserDTO {
}
