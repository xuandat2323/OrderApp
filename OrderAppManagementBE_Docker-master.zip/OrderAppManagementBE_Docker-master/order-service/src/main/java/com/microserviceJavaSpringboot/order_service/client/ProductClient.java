package com.microserviceJavaSpringboot.order_service.client;

public class ProductClient {
}
