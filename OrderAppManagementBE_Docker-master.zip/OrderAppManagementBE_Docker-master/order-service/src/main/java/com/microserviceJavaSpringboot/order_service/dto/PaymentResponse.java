package com.microserviceJavaSpringboot.order_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentResponse {
    private String payUrl;
    private String status;       // PENDING, SUCCESS, FAILED
    private String message;      // Thông báo từ cổng thanh toán
    private String transactionId; // Mã giao dịch (requestId / transactionId từ Momo hoặc VNPay)
}