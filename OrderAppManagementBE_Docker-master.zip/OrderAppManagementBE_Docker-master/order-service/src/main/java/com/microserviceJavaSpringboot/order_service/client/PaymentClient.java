package com.microserviceJavaSpringboot.order_service.client;

import com.microserviceJavaSpringboot.order_service.dto.MomoResponseDTO;
import com.microserviceJavaSpringboot.order_service.dto.PaymentRequestDTO;
import com.microserviceJavaSpringboot.order_service.dto.PaymentResponse;
import com.microserviceJavaSpringboot.order_service.dto.VnPayResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "payment-service")
public interface PaymentClient {

    @PostMapping("/api/payment/vnpay/create")
    PaymentResponse createVNPayPayment(@RequestBody PaymentRequestDTO request);

    // Gọi sang payment-service tạo thanh toán MoMo
    @PostMapping("/api/payment/momo/create")
    PaymentResponse createMomoPayment(@RequestBody PaymentRequestDTO request);
}
