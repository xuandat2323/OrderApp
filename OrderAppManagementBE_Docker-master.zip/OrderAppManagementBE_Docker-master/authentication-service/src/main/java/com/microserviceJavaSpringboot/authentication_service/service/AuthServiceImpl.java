package com.microserviceJavaSpringboot.authentication_service.service;

import com.microserviceJavaSpringboot.authentication_service.client.EmployeeClient;
import com.microserviceJavaSpringboot.authentication_service.client.UserClient;
import com.microserviceJavaSpringboot.authentication_service.dto.*;
import com.microserviceJavaSpringboot.authentication_service.enums.Roles;
import com.microserviceJavaSpringboot.authentication_service.models.Credential;
import com.microserviceJavaSpringboot.authentication_service.models.Role;
import com.microserviceJavaSpringboot.authentication_service.repository.CredentialRepository;
import com.microserviceJavaSpringboot.authentication_service.repository.RoleRepository;
import com.microserviceJavaSpringboot.authentication_service.security.jwt.JwtUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.ResponseCookie;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;
import java.util.Random;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService{
    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    CredentialRepository credentialRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    JwtUtils jwtUtils;
    @Autowired
    private UserClient userClient;
    @Autowired
    private EmployeeClient employeeClient;
    @Autowired
    private final RedisTemplate<String, String> redisTemplate;
//    @Autowired
//    private final JavaMailSender mailSender;


    @Value("${otp.ttl-minutes}")
    private long otpTtlMinutes;

    private static final String OTP_PREFIX = "OTP:";

    @Override
    public CredentialsInfoResponse authenticateUser(LoginRequest request) {
        String identifier = request.getIdentifier();
        String password = request.getPassword();

        System.out.println("Request được truyền từ request: " + identifier);

        boolean isEmail = identifier.contains("@");

        String username = isEmail
                ? credentialRepository.findUsernameByEmail(identifier) // Chuyển email → username
                : identifier;

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, request.getPassword())
        );

        System.out.println("pass được truyền từ request: " + authentication);

        SecurityContextHolder.getContext().setAuthentication(authentication);

        CredentialsDetailsImpl userPrincipal = (CredentialsDetailsImpl) authentication.getPrincipal();

        Roles role = userPrincipal.getRoles().stream()
                .findFirst()
                .map(Role::getName)
                .orElse(Roles.ROLE_UNKNOWN);

        // Gọi microservice để lấy thông tin user/employee
        AuthUserDto userDto;
        if (role == Roles.ROLE_USER) {
            userDto = userClient.getUserByEmail(userPrincipal.getEmail());
        } else if (role == Roles.ROLE_EMPLOYEE || role == Roles.ROLE_ADMIN) {
            userDto = employeeClient.getEmployeeByEmail(userPrincipal.getEmail());
        } else {
            throw new RuntimeException("Unauthorized role");
        }

        // Tạo JWT và cookie
        String jwt = jwtUtils.generateJwtTokenFromAuthentication(authentication);
        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userPrincipal.getEmail(), role);

        return new CredentialsInfoResponse(
                jwt,
                jwtCookie,
                userDto.getId(),
                userPrincipal.getEmail(),
                userPrincipal.getUsername(),
                List.of(role.name())
        );
    }

    @Override
    public CredentialsInfoResponse registerUser(SignupRequest request) {
        // 1. Kiểm tra username/email đã tồn tại
        if (credentialRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        if (credentialRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        // 2. Tạo credential mới
        Credential credential = Credential.builder()
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .email(request.getEmail())
                .build();

        // 3. Gán role mặc định (ROLE_USER hoặc ROLE_EMPLOYEE tuỳ theo request)
        Role defaultRole = roleRepository.findByName(request.getRole())
                .orElseThrow(() -> new RuntimeException("Default role not found"));
        credential.setRoles(Set.of(defaultRole));

        // 4. Lưu credential vào DB
        credentialRepository.save(credential);

        Roles role = request.getRole() != null ? request.getRole() : Roles.ROLE_USER;

        // 5. Gửi thông tin sang user-service hoặc employee-service
        if (role == Roles.ROLE_USER) {
            CreateUserRequest userRequest = new CreateUserRequest(
                    request.getFirstName(),
                    request.getLastName(),
                    request.getPhone(),
                    request.getAddress(),
                    request.getEmail()
            );
            userClient.createUser(userRequest);
        } else if (role == Roles.ROLE_EMPLOYEE || role == Roles.ROLE_ADMIN) {
            CreateEmployeeRequest employeeRequest = new CreateEmployeeRequest(
                    request.getFirstName(),
                    request.getLastName(),
                    request.getPhone(),
                    request.getAddress(),
                    request.getEmail()
            );
            employeeClient.createEmployee(employeeRequest);
        }


        // 6. Xác thực user vừa tạo
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        CredentialsDetailsImpl userPrincipal = (CredentialsDetailsImpl) authentication.getPrincipal();

        // 7. Gọi lại user/employee service để lấy ID (nếu cần)
        AuthUserDto userDto;
        if (request.getRole() == Roles.ROLE_USER) {
            userDto = userClient.getUserByEmail(request.getEmail());
        } else {
            userDto = employeeClient.getEmployeeByEmail(request.getEmail());
        }

        // 8. Tạo JWT + cookie
        String jwt = jwtUtils.generateJwtTokenFromAuthentication(authentication);
        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(request.getEmail(), request.getRole());

        // 9. Trả về CredentialsInfoResponse
        return new CredentialsInfoResponse(
                jwt,
                jwtCookie,
                userDto.getId(),
                credential.getEmail(),
                credential.getUsername(),
                List.of(request.getRole().name())
        );
    }

    @Override
    public CredentialsInfoResponse updateUser(UpdateRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        System.out.println("Request được truyền từ request: " + authentication);

        if (authentication == null || !(authentication.getPrincipal() instanceof CredentialsDetailsImpl)) {
            throw new RuntimeException("User not authenticated");
        }
        CredentialsDetailsImpl userPrincipal = (CredentialsDetailsImpl) authentication.getPrincipal();
        String currentEmail = userPrincipal.getEmail();

        System.out.println("Request được truyền từ request: " + currentEmail);

        Credential credential = credentialRepository.findByEmail(currentEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (request.getUsername() != null && !request.getUsername().equals(credential.getUsername())) {
            if (credentialRepository.existsByUsername(request.getUsername())) {
                throw new RuntimeException("Username already exists");
            }
            credential.setUsername(request.getUsername());
        }

        if (request.getEmail() != null && !request.getEmail().equals(credential.getEmail())) {
            if (credentialRepository.existsByEmail(request.getEmail())) {
                throw new RuntimeException("Email already exists");
            }
            credential.setEmail(request.getEmail());
        }

        if (request.getPassword() != null && !request.getPassword().isEmpty()) {
            credential.setPassword(passwordEncoder.encode(request.getPassword()));
        }

        credentialRepository.save(credential);

        Roles role = userPrincipal.getRoles().stream()
                .findFirst()
                .map(Role::getName)
                .orElseThrow(() -> new RuntimeException("Role not found"));

        AuthUserDto updatedUserDto;
        if (role == Roles.ROLE_USER) {
            CreateUserRequest userRequest = new CreateUserRequest(
                    request.getFirstName(),
                    request.getLastName(),
                    request.getPhone(),
                    request.getAddress(),
                    request.getEmail() != null ? request.getEmail() : currentEmail
            );
            updatedUserDto = userClient.updateUser(userRequest);
        } else if (role == Roles.ROLE_EMPLOYEE) {
            CreateEmployeeRequest employeeRequest = new CreateEmployeeRequest(
                    request.getFirstName(),
                    request.getLastName(),
                    request.getPhone(),
                    request.getAddress(),
                    request.getEmail() != null ? request.getEmail() : currentEmail
            );
            updatedUserDto = employeeClient.updateEmployee(employeeRequest);
        } else {
            throw new RuntimeException("Unauthorized role");
        }

        String jwt = jwtUtils.generateJwtTokenFromAuthentication(authentication);
        ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(
                request.getEmail() != null ? request.getEmail() : currentEmail,
                role
        );

        return new CredentialsInfoResponse(
                jwt,
                jwtCookie,
                updatedUserDto.getId(),
                request.getEmail() != null ? request.getEmail() : credential.getEmail(),
                request.getUsername() != null ? request.getUsername() : credential.getUsername(),
                List.of(role.name())
        );
    }

    @Override
    public String deleteUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof CredentialsDetailsImpl)) {
            throw new RuntimeException("User not authenticated");
        }
        CredentialsDetailsImpl userPrincipal = (CredentialsDetailsImpl) authentication.getPrincipal();
        String currentEmail = userPrincipal.getEmail();

        Credential credential = credentialRepository.findByEmail(currentEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Roles role = userPrincipal.getRoles().stream()
                .findFirst()
                .map(Role::getName)
                .orElseThrow(() -> new RuntimeException("Role not found"));

        try {
            if (role == Roles.ROLE_USER) {
                userClient.deleteUser(currentEmail);
            } else if (role == Roles.ROLE_EMPLOYEE) {
                employeeClient.deleteEmployee(currentEmail);
            } else {
                throw new RuntimeException("Unauthorized role");
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete user in related service: " + e.getMessage());
        }

        credentialRepository.delete(credential);

        SecurityContextHolder.clearContext();

        return "User deleted successfully";
    }

    @Override
    public void sendOtpToEmail(String email) {
        String otp = generateOtp();
        redisTemplate.opsForValue().set("otp:" + email, otp, Duration.ofMinutes(otpTtlMinutes));

        // Gửi mail
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your OTP Code");
        message.setText("Your OTP is: " + otp);
//        mailSender.send(message);
    }

    @Override
    public boolean verifyOtp(String email, String otp) {
        String storedOtp = redisTemplate.opsForValue().get("otp:" + email);
        return storedOtp != null && storedOtp.equals(otp);
    }

    @Override
    public void resetPassword(String email, String newPassword) {
        Credential user = credentialRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setPassword(passwordEncoder.encode(newPassword));
        credentialRepository.save(user);
    }

    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

}
