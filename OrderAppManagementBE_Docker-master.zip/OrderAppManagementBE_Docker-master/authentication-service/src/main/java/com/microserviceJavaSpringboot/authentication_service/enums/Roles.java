package com.microserviceJavaSpringboot.authentication_service.enums;

public enum Roles {
    ROLE_USER,
    ROLE_EMPLOYEE,
    ROLE_ADMIN,
    ROLE_UNKNOWN
}