package com.microserviceJavaSpringboot.authentication_service.repository;

import com.microserviceJavaSpringboot.authentication_service.models.Credential;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface CredentialRepository extends JpaRepository<Credential,Short> {

    Optional<Credential> findByUsername(String username);

    Optional<Credential> findById(Short id);

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);

    Credential findByEmailOrUsername(String email, String username);

    Optional<Credential> findByEmail(String email);

    @Query("SELECT c.username FROM Credential c WHERE c.email = :email")
    String findUsernameByEmail(String email);

}