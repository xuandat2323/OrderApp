package com.microserviceJavaSpringboot.authentication_service.client;

import com.microserviceJavaSpringboot.authentication_service.dto.AuthUserDto;
import com.microserviceJavaSpringboot.authentication_service.dto.CreateUserRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "user-service")
public interface UserClient {

    @GetMapping("/api/internal/users-service/by-email")
    AuthUserDto getUserByEmail(@RequestParam("email") String email);

    @PostMapping("/api/internal/users-service")
    AuthUserDto createUser(@RequestBody CreateUserRequest request);

    @PutMapping("/api/internal/users-service/update")
    AuthUserDto updateUser(@RequestBody  CreateUserRequest request);

    @DeleteMapping("/api/internal/users-service/{email}")
    void deleteUser(@PathVariable String email);
}