package com.microserviceJavaSpringboot.authentication_service.controller;

import com.microserviceJavaSpringboot.authentication_service.dto.ResetPasswordRequest;
import com.microserviceJavaSpringboot.authentication_service.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth/password")
@RequiredArgsConstructor
public class PasswordController {

    private final AuthService authService;

    @PostMapping("/forgot")
    public ResponseEntity<String> sendOtpForReset(@RequestParam String email) {
        authService.sendOtpToEmail(email);
        return ResponseEntity.ok("OTP sent to email for password reset.");
    }


    @PostMapping("/reset")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest request) {
        boolean valid = authService.verifyOtp(request.getEmail(), request.getOtp());
        if (!valid) {
            return ResponseEntity.badRequest().body("Invalid or expired OTP.");
        }

        authService.resetPassword(request.getEmail(), request.getNewPassword());
        return ResponseEntity.ok("Password reset successful.");
    }
}
