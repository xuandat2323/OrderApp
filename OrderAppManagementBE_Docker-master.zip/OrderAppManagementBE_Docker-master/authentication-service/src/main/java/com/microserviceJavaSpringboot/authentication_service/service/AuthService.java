package com.microserviceJavaSpringboot.authentication_service.service;
import com.microserviceJavaSpringboot.authentication_service.dto.CredentialsInfoResponse;
import com.microserviceJavaSpringboot.authentication_service.dto.LoginRequest;
import com.microserviceJavaSpringboot.authentication_service.dto.SignupRequest;
import com.microserviceJavaSpringboot.authentication_service.dto.UpdateRequest;
import com.microserviceJavaSpringboot.authentication_service.models.ResponseObject;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


public interface AuthService {
    CredentialsInfoResponse authenticateUser(LoginRequest request);
    CredentialsInfoResponse registerUser(SignupRequest request);
    CredentialsInfoResponse updateUser(UpdateRequest request);
    String deleteUser();
    void sendOtpToEmail(String email);
    boolean verifyOtp(String email, String otp);
    void resetPassword(String email, String newPassword);
}
