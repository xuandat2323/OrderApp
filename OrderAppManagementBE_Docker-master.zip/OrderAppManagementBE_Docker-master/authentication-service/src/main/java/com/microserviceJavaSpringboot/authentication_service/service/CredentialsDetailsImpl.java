package com.microserviceJavaSpringboot.authentication_service.service;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.microserviceJavaSpringboot.authentication_service.models.Credential;
import com.microserviceJavaSpringboot.authentication_service.models.Role;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serial;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class CredentialsDetailsImpl implements UserDetails {
    @Serial
    private static final long serialVersionUID = 1L;

    @Getter
    private final Short id;
    private final String username;
    @Getter
    private final String email;

    @JsonIgnore
    private final String password;

    @Getter
    private final Set<Role> roles;

    // Constructor to initialize the user details object
    public CredentialsDetailsImpl(Short id, String username, String email, String password, Set<Role> roles) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.roles = roles;
    }


    // Static method to build the UserDetails object from a User entity
    public static CredentialsDetailsImpl build(Credential credential) {
        return new CredentialsDetailsImpl(
                credential.getId(),
                credential.getUsername(),
                credential.getEmail(), // thêm dòng này
                credential.getPassword(),
                credential.getRoles()
        );
    }


    // Returns authorities based on roles
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles.stream()
                .map(role -> new SimpleGrantedAuthority(role.getName().name()))
                .collect(Collectors.toList());
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    // Override equals and hashcode to compare by user ID
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        CredentialsDetailsImpl user = (CredentialsDetailsImpl) o;
        return Objects.equals(id, user.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
