package com.microserviceJavaSpringboot.authentication_service.controller;

import com.microserviceJavaSpringboot.authentication_service.dto.CredentialsInfoResponse;
import com.microserviceJavaSpringboot.authentication_service.dto.LoginRequest;
import com.microserviceJavaSpringboot.authentication_service.dto.SignupRequest;
import com.microserviceJavaSpringboot.authentication_service.dto.UpdateRequest;
import com.microserviceJavaSpringboot.authentication_service.models.ResponseObject;
import com.microserviceJavaSpringboot.authentication_service.security.jwt.JwtUtils;
import com.microserviceJavaSpringboot.authentication_service.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final JwtUtils jwtUtils;

    @PostMapping("/login")
    public ResponseEntity<ResponseObject> login(@RequestBody LoginRequest request) {
        try{
            CredentialsInfoResponse response = authService.authenticateUser(request);
            return ResponseEntity.ok()
                    .header(HttpHeaders.SET_COOKIE)
                    .body(new ResponseObject("ok", "Login ok", response));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(new ResponseObject("error", e.getMessage(), ""));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<ResponseObject> register(@RequestBody SignupRequest request) {
        try{
            CredentialsInfoResponse response = authService.registerUser(request);
            return ResponseEntity.ok()
                    .header(HttpHeaders.SET_COOKIE)
                    .body(new ResponseObject("ok", "Login ok", response));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(new ResponseObject("error", e.getMessage(), ""));
        }
    }

    @PostMapping("/update")
    public ResponseEntity<ResponseObject> update(@RequestBody UpdateRequest request) {
        try{
            CredentialsInfoResponse response = authService.updateUser(request);
            return ResponseEntity.ok()
                    .header(HttpHeaders.SET_COOKIE)
                    .body(new ResponseObject("ok", "Login ok", response));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(new ResponseObject("error", e.getMessage(), ""));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<ResponseObject> logout() {
        ResponseCookie cleanCookie = jwtUtils.getCleanJwtCookie();

        return ResponseEntity.ok()
                .header(HttpHeaders.SET_COOKIE, cleanCookie.toString())
                .body( new ResponseObject("ok", "Logged out successfully", ""));
    }

    @DeleteMapping("/delete")
    public ResponseEntity<ResponseObject> delete() {
        String response = authService.deleteUser();
        return ResponseEntity.ok()
                .body(new ResponseObject("ok", "User deleted successfully", response));
    }

    @PostMapping("/send-otp")
    public ResponseEntity<String> sendOtp(@RequestParam String email) {
        authService.sendOtpToEmail(email);
        return ResponseEntity.ok("OTP sent to email.");
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@RequestParam String email, @RequestParam String otp) {
        boolean isValid = authService.verifyOtp(email, otp);
        if (isValid) {
            return ResponseEntity.ok("OTP verified.");
        } else {
            return ResponseEntity.badRequest().body("Invalid OTP.");
        }
    }
}
