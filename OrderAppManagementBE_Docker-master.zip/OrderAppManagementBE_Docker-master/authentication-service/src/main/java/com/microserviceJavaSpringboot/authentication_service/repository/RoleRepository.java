package com.microserviceJavaSpringboot.authentication_service.repository;

import com.microserviceJavaSpringboot.authentication_service.enums.Roles;
import com.microserviceJavaSpringboot.authentication_service.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role,Short> {
    Optional<Role> findByName(Roles name);

}