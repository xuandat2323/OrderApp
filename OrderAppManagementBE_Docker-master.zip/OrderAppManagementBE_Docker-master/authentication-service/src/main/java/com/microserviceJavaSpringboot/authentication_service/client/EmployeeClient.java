package com.microserviceJavaSpringboot.authentication_service.client;

import com.microserviceJavaSpringboot.authentication_service.dto.AuthUserDto;
import com.microserviceJavaSpringboot.authentication_service.dto.CreateEmployeeRequest;
import com.microserviceJavaSpringboot.authentication_service.dto.CreateUserRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "employee-service")
public interface EmployeeClient {

    @GetMapping("/api/internal/employees/by-email")
    AuthUserDto getEmployeeByEmail(@RequestParam("email") String email);

    @PostMapping("/api/internal/employees")
    void createEmployee(@RequestBody CreateEmployeeRequest request);

    @PutMapping("/api/internal/employees/update")
    AuthUserDto updateEmployee(@RequestBody CreateEmployeeRequest request);

    @DeleteMapping("/api/internal/employees/{email}")
    void deleteEmployee(@PathVariable String email);
}