package com.microserviceJavaSpringboot.authentication_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.ResponseCookie;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CredentialsInfoResponse {
    private String token;
    private ResponseCookie jwtCookie;
    private Long id;
    private String email;
    private String username;
    private List<String> roles;
}
