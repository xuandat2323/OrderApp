package com.microserviceJavaSpringboot.employee_service.controller;

import com.microserviceJavaSpringboot.employee_service.dto.AuthUserDto;
import com.microserviceJavaSpringboot.employee_service.dto.CreateEmployeeRequest;
import com.microserviceJavaSpringboot.employee_service.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/internal/employees")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;

    @GetMapping("/{id}")
    public AuthUserDto getUserById(@PathVariable Short id) {
        return employeeService.getEmployeeById(id);
    }

    @PostMapping
    public void createEmployee(@RequestBody CreateEmployeeRequest request) {
        employeeService.createEmployee(request);
    }

    @GetMapping("/by-email")
    public AuthUserDto getEmployeeByEmail(@RequestParam String email) {
        return employeeService.getEmployeeByEmail(email);
    }

    @DeleteMapping("/delete/{email}")
    public void deleteEmployee(@PathVariable String email) {
        employeeService.deleteEmployee(email);
    }
}
