package com.microserviceJavaSpringboot.employee_service.service;

import com.microserviceJavaSpringboot.employee_service.dto.AuthUserDto;
import com.microserviceJavaSpringboot.employee_service.dto.CreateEmployeeRequest;

public interface EmployeeService {
    AuthUserDto getEmployeeById(Short id);

    AuthUserDto createEmployee(CreateEmployeeRequest request);

    AuthUserDto getEmployeeByEmail(String email);

    AuthUserDto updateEmployee(CreateEmployeeRequest request);

    void deleteEmployee(String email);
}