package com.microserviceJavaSpringboot.employee_service.service;

import com.microserviceJavaSpringboot.employee_service.dto.AuthUserDto;
import com.microserviceJavaSpringboot.employee_service.dto.CreateEmployeeRequest;
import com.microserviceJavaSpringboot.employee_service.model.Employee;
import com.microserviceJavaSpringboot.employee_service.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;

    @Override
    public AuthUserDto getEmployeeById(Short id) {
        Employee user = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return new AuthUserDto(
                user.getId(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName()
        );
    }

    @Override
    public AuthUserDto createEmployee(CreateEmployeeRequest request) {
        Employee employee = Employee.builder()
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .phone(request.getPhone())
                .address(request.getAddress())
                .email(request.getEmail())
                .hiredDate(request.getHiredDate())
                .build();

        Employee savedEmployee = employeeRepository.save(employee);

        return new AuthUserDto(
                savedEmployee.getId(),
                savedEmployee.getEmail(),
                savedEmployee.getFirstName(),
                savedEmployee.getLastName()
        );
    }

    @Override
    public AuthUserDto getEmployeeByEmail(String email) {
        Employee employee = employeeRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        return new AuthUserDto(
                employee.getId(),
                employee.getEmail(),
                employee.getFirstName(),
                employee.getLastName()
        );
    }

    @Override
    public AuthUserDto updateEmployee(CreateEmployeeRequest request) {
        // 1. Tìm user theo email hiện tại
        String currentEmail = request.getEmail();

        Employee employee = employeeRepository.findByEmail(currentEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // 2. Kiểm tra email mới (nếu có) để tránh trùng lặp
        if (request.getEmail() != null && !request.getEmail().equals(currentEmail)) {
            if (employeeRepository.existsByEmail((request.getEmail()))) {
                throw new RuntimeException("Email already exists");
            }
            employee.setEmail(request.getEmail());
        }

        // 3. Cập nhật các trường khác nếu được cung cấp
        if (request.getFirstName() != null) {
            employee.setFirstName(request.getFirstName());
        }
        if (request.getLastName() != null) {
            employee.setLastName(request.getLastName());
        }
        if (request.getPhone() != null) {
            employee.setPhone(request.getPhone());
        }
        if (request.getAddress() != null) {
            employee.setAddress(request.getAddress());
        }

        if( request.getHiredDate() != null ) {
            employee.setHiredDate(request.getHiredDate());
        }

        // 4. Lưu user cập nhật vào DB
        Employee updatedEmployee = employeeRepository.save(employee);

        // 5. Trả về AuthUserDto
        return new AuthUserDto(
                updatedEmployee.getId(),
                updatedEmployee.getEmail(),
                updatedEmployee.getFirstName(),
                updatedEmployee.getLastName()
        );
    }


    @Override
    public void deleteEmployee(String email) {
        Employee employee = employeeRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        employeeRepository.delete(employee);
    }
}
