package com.microserviceJavaSpringboot.employee_service.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="employee")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Employee implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="EmployeeId", unique = true)
    private Short id;
    @Column(name="LastName", length=50)
    private String lastName;
    @Column(name="FirstName", length=50)
    private String firstName;
    @Column(name="Phone", length=12)
    private String phone;
    @Column(name="Address", length = 256)
    private String address;
    @Column(name="Email", length=50)
    private String email;
    @Column(name="HiredDate", length = 30)
    private String hiredDate;
}