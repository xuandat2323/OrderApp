package com.microserviceJavaSpringboot.user_service.service;

import com.microserviceJavaSpringboot.user_service.dto.AuthUserDto;
import com.microserviceJavaSpringboot.user_service.dto.CreateUserRequest;
import com.microserviceJavaSpringboot.user_service.model.User;

public interface UserService {
//    User createUser(CreateUserRequest request);
//    User getUserByEmail(String email);
    AuthUserDto getUserById(Short id);
    AuthUserDto createUser(CreateUserRequest request);
    AuthUserDto getUserByEmail(String email);
    AuthUserDto updateUser(CreateUserRequest request);
    void deleteUser(String email);
}