package com.microserviceJavaSpringboot.user_service.model;

//import com.microserviceJavaSpringboot.user_service.enums.Roles;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="user")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="UserId", unique = true)
    private Short id;
    @Column(name="LastName", length=50)
    private String lastName;
    @Column(name="FirstName", length=50)
    private String firstName;
    @Column(name="Phone", length=12)
    private String phone;
    @Column(name="Address", length = 256)
    private String address;
    @Column(name="Email", length=50)
    private String email;
}