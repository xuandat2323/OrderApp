package com.microserviceJavaSpringboot.user_service.controller;


import com.microserviceJavaSpringboot.user_service.dto.AuthUserDto;
import com.microserviceJavaSpringboot.user_service.dto.CreateUserRequest;
import com.microserviceJavaSpringboot.user_service.model.User;
import com.microserviceJavaSpringboot.user_service.service.UserService;
import com.microserviceJavaSpringboot.user_service.service.UserServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/internal/users-service")
@RequiredArgsConstructor
public class UserInternalController {
    private final UserService userService;

    @GetMapping("/{id}")
    public AuthUserDto getUserById(@PathVariable Short id) {
        return userService.getUserById(id);
    }

    @PostMapping
    public AuthUserDto createUser(@RequestBody CreateUserRequest request) {
        return userService.createUser(request);
    }

    @PutMapping("/update")
    public AuthUserDto updateUser(@RequestBody CreateUserRequest request) {
        return userService.updateUser(request);
    }

    @GetMapping("/by-email")
    public AuthUserDto getUserByEmail(@RequestParam String email) {
        return userService.getUserByEmail(email);
    }

    @DeleteMapping("/{email}")
    public void deleteUser(@PathVariable String email) {
        userService.deleteUser(email);
    }
}
