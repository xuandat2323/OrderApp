package com.microserviceJavaSpringboot.payment_service.service;

import com.microserviceJavaSpringboot.payment_service.dto.PaymentRequestDTO;
import com.microserviceJavaSpringboot.payment_service.dto.MomoResponseDTO;
import com.microserviceJavaSpringboot.payment_service.event.PaymentEventPublisher;
import com.microserviceJavaSpringboot.payment_service.model.PaymentTransaction;
import com.microserviceJavaSpringboot.payment_service.repository.PaymentTransactionRepository;
import com.microserviceJavaSpringboot.payment_service.util.HmacUtil;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;

@Service
public class MomoPaymentService {

    @Value("${momo.endpoint}")
    private String endpoint;

    @Value("${momo.partnerCode}")
    private String partnerCode;

    @Value("${momo.accessKey}")
    private String accessKey;

    @Value("${momo.secretKey}")
    private String secretKey;

    @Value("${momo.returnUrl}")
    private String returnUrl;

    @Value("${momo.ipnUrl}")
    private String ipnUrl;

    private final PaymentTransactionRepository repository;
    private final PaymentEventPublisher eventPublisher;

    public MomoPaymentService(PaymentTransactionRepository repository,
                              PaymentEventPublisher eventPublisher) {
        this.repository = repository;
        this.eventPublisher = eventPublisher;
    }

    /**
     * Tạo yêu cầu thanh toán MoMo
     */
    public MomoResponseDTO createPayment(PaymentRequestDTO req) throws Exception {
        String requestId = String.valueOf(System.currentTimeMillis());
        String orderId = req.getOrderId();
        String amount = String.valueOf(req.getAmount());
        String userId = req.getUserId(); // 🧩 Lấy userId từ request
        String orderInfo = (req.getOrderInfo() != null && !req.getOrderInfo().isBlank())
                ? req.getOrderInfo()
                : "Thanh toán đơn hàng #" + req.getOrderId();
        String requestType = "captureWallet";

        // Tạo chữ ký
        String rawSignature = "accessKey=" + accessKey +
                "&amount=" + amount +
                "&extraData=" + "" +
                "&ipnUrl=" + ipnUrl +
                "&orderId=" + orderId +
                "&orderInfo=" + orderInfo +
                "&partnerCode=" + partnerCode +
                "&redirectUrl=" + returnUrl +
                "&requestId=" + requestId +
                "&requestType=" + requestType;

        String signature = HmacUtil.hmacSHA256(secretKey, rawSignature);

        // JSON body gửi đến MoMo
        JSONObject body = new JSONObject();
        body.put("partnerCode", partnerCode);
        body.put("requestId", requestId);
        body.put("amount", amount);
        body.put("orderId", orderId);
        body.put("orderInfo", orderInfo);
        body.put("redirectUrl", returnUrl);
        body.put("ipnUrl", ipnUrl);
        body.put("requestType", requestType);
        body.put("extraData", "");
        body.put("lang", "vi");
        body.put("signature", signature);

        // Lưu transaction trạng thái PENDING
        PaymentTransaction tx = new PaymentTransaction();
        tx.setOrderId(orderId);
        tx.setUserId(userId); // 🧩 Lưu userId
        tx.setRequestId(requestId);
        tx.setAmount(req.getAmount());
        tx.setStatus("PENDING");
        tx.setCreatedAt(LocalDateTime.now());
        repository.save(tx);

        // Gửi request đến MoMo
        RestTemplate rest = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(body.toString(), headers);
        ResponseEntity<String> resp = rest.postForEntity(endpoint, entity, String.class);

        JSONObject jsonResp = new JSONObject(resp.getBody());
        String payUrl = jsonResp.optString("payUrl", null);
        int resultCode = jsonResp.optInt("resultCode", -1);
        String message = jsonResp.optString("message", null);

        // Cập nhật lại DB
        tx.setPayUrl(payUrl);
        tx.setResultCode(resultCode);
        tx.setMessage(message);
        repository.save(tx);

        return MomoResponseDTO.builder()
                .payUrl(payUrl)
                .status("PENDING")
                .message(message)
                .transactionId(requestId)
                .build();
    }

    /**
     * Xử lý callback IPN từ MoMo
     */
    public boolean handleIpn(JSONObject ipnJson) {
        try {
            String orderId = ipnJson.getString("orderId");
            String amount = ipnJson.getString("amount");
            String message = ipnJson.optString("message", "");
            String resultCode = ipnJson.optString("resultCode", "");
            String transId = ipnJson.optString("transId", "");

            PaymentTransaction tx = repository.findByOrderId(orderId).orElse(null);
            if (tx != null) {
                tx.setResultCode(Integer.parseInt(resultCode));
                tx.setMessage(message);
                tx.setStatus("0".equals(resultCode) ? "SUCCESS" : "FAILED");
                tx.setUpdatedAt(LocalDateTime.now());
                repository.save(tx);
            }

            // Nếu thanh toán thành công → gửi event kèm userId
            if ("0".equals(resultCode)) {
                eventPublisher.publishPaymentSuccess(orderId, "MOMO-" + transId, Long.parseLong(amount), "MOMO");
            } else {
                eventPublisher.publishPaymentFailed(orderId, Long.parseLong(amount), message, "MOMO");
            }

            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Giả lập MoMo IPN (dành cho test)
     */
    public void simulateMomo(String orderId, long amount, boolean success) {
        System.out.println("🧪 Simulating MoMo payment for orderId=" + orderId + ", success=" + success);

        PaymentTransaction tx = repository.findByOrderId(orderId).orElse(null);
        if (tx == null) {
            tx = new PaymentTransaction();
            tx.setOrderId(orderId);
            tx.setAmount(amount);
            tx.setCreatedAt(LocalDateTime.now());
        }

        tx.setStatus(success ? "SUCCESS" : "FAILED");
        tx.setUpdatedAt(LocalDateTime.now());
        repository.save(tx);

        if (success) {
            eventPublisher.publishPaymentSuccess(orderId, "MOMO-" + orderId, amount, "MOMO");
            System.out.println("✅ [Simulated] Payment success event sent for order " + orderId);
        } else {
            eventPublisher.publishPaymentFailed(orderId, amount, "Giả lập thanh toán thất bại", "MOMO");
            System.out.println("❌ [Simulated] Payment failed event sent for order " + orderId);
        }
    }
}
