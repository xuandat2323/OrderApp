package com.microserviceJavaSpringboot.payment_service.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "payment_transactions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Builder
public class PaymentTransaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String orderId;
    private String userId;
    private String requestId;
    private Long amount;
    @Column(name = "pay_url", columnDefinition = "TEXT")
    private String payUrl;
    private Integer resultCode;
    private String message;
    private String status; // PENDING, SUCCESS, FAILED
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

}