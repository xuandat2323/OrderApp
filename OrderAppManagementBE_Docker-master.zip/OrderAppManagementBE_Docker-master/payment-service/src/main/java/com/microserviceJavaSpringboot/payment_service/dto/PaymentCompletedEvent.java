package com.microserviceJavaSpringboot.payment_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class PaymentCompletedEvent {
    private String orderId;
    private Long amount;
    private String transactionId; // requestId
}