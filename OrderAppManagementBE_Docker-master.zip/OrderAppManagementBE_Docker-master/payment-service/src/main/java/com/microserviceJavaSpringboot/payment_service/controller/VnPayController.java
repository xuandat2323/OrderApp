package com.microserviceJavaSpringboot.payment_service.controller;

import com.microserviceJavaSpringboot.payment_service.dto.PaymentRequestDTO;
import com.microserviceJavaSpringboot.payment_service.dto.VnPayResponseDTO;
import com.microserviceJavaSpringboot.payment_service.event.PaymentEventPublisher;
import com.microserviceJavaSpringboot.payment_service.service.VnPayService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payment/vnpay")
@RequiredArgsConstructor
public class VnPayController {

    private final VnPayService vnPayService;
    private final PaymentEventPublisher eventPublisher;

    /**
     * API tạo link thanh toán VNPay
     */
    @PostMapping("/create")
    public VnPayResponseDTO createPayment(@RequestBody PaymentRequestDTO request) {
        try {
            System.out.println("🔹 Received VNPay request: " + request);
            return vnPayService.createPaymentUrl(
                    request.getOrderId(), request.getUserId(), request.getAmount().longValue());
        } catch (Exception e) {
            e.printStackTrace();
            return VnPayResponseDTO.builder()
                    .status("FAILED")
                    .message("Lỗi tạo yêu cầu thanh toán: " + e.getMessage())
                    .build();
        }
    }

    /**
     * API nhận callback IPN từ VNPay (server to server)
     */
    @PostMapping("/ipn")
    public ResponseEntity<String> ipnCallback(@RequestParam Map<String, String> allParams) {
        if (allParams == null || allParams.isEmpty()) {
            System.err.println(" VNPay IPN received with no parameters!");
            return ResponseEntity.badRequest().body(" Missing VNPay parameters");
        }

        try {
            vnPayService.handleIpn(allParams);
            return ResponseEntity.ok("OK"); // luôn trả OK cho VNPay để tránh retry
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(200).body("OK");
        }
    }

    /**
     * API cho người dùng redirect về sau khi thanh toán (trên browser)
     */
    @GetMapping("/return")
    public ResponseEntity<String> paymentReturn(HttpServletRequest request) {
        String vnp_ResponseCode = request.getParameter("vnp_ResponseCode");
        String orderId = request.getParameter("vnp_TxnRef");
        long amount = 0L;

        try {
            amount = Long.parseLong(request.getParameter("vnp_Amount")) / 100;
        } catch (Exception ignored) {}

        if ("00".equals(vnp_ResponseCode)) {
            eventPublisher.publishPaymentSuccess(orderId, "VNPAY-" + orderId, amount, "VNPAY");
            return ResponseEntity.ok("Thanh toán VNPay thành công (Order ID: " + orderId + ")");
        } else {
            String message = switch (vnp_ResponseCode) {
                case "24" -> "Người dùng hủy giao dịch";
                case "51" -> "Không đủ số dư tài khoản";
                case "99" -> "Lỗi không xác định";
                default -> "Thanh toán VNPay thất bại (code=" + vnp_ResponseCode + ")";
            };

            eventPublisher.publishPaymentFailed(orderId, amount, message, "VNPAY");
            return ResponseEntity.ok("❌ " + message);
        }
    }

    @PostMapping("/simulate/success")
    public ResponseEntity<String> simulateSuccess(@RequestParam String orderId, @RequestParam Long amount, @RequestParam String userId) {
        vnPayService.simulateVnPay(orderId, amount, userId, true);
        return ResponseEntity.ok("Đã giả lập thanh toán VNPay thành công cho orderId=" + orderId);
    }

    @PostMapping("/simulate/fail")
    public ResponseEntity<String> simulateFail(@RequestParam String orderId, @RequestParam Long amount, @RequestParam String userId) {
        vnPayService.simulateVnPay(orderId, amount, userId, false);
        return ResponseEntity.ok("Đã giả lập thanh toán VNPay thất bại cho orderId=" + orderId);
    }


}
