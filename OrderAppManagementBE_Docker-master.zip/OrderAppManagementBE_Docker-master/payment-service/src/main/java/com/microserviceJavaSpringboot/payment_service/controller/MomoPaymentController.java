package com.microserviceJavaSpringboot.payment_service.controller;

import com.microserviceJavaSpringboot.payment_service.dto.PaymentRequestDTO;
import com.microserviceJavaSpringboot.payment_service.dto.MomoResponseDTO;
import com.microserviceJavaSpringboot.payment_service.event.PaymentEventPublisher;
import com.microserviceJavaSpringboot.payment_service.service.MomoPaymentService;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment/momo")
@RequiredArgsConstructor
public class MomoPaymentController {

    private final MomoPaymentService momoPaymentService;
    private final PaymentEventPublisher eventPublisher;

    /**
     * ✅ API tạo giao dịch MoMo
     */
    @PostMapping("/create")
    public ResponseEntity<MomoResponseDTO> createPayment(@RequestBody PaymentRequestDTO request) throws Exception {
        return ResponseEntity.ok(momoPaymentService.createPayment(request));
    }

    /**
     * ✅ IPN callback từ MoMo (server → server)
     */
    @PostMapping("/ipn")
    public ResponseEntity<String> ipn(@RequestBody String body) {
        try {
            JSONObject json = new JSONObject(body);
            boolean ok = momoPaymentService.handleIpn(json);

            if (ok) {
                return ResponseEntity.ok("OK");
            } else {
                // Khi chữ ký sai hoặc thất bại, cũng publish event FAILED
                String orderId = json.optString("orderId", "unknown");
                eventPublisher.publishPaymentFailed(orderId, 0, "Sai chữ ký hoặc thất bại IPN", "MOMO");
                return ResponseEntity.ok("OK"); // luôn trả OK để MoMo không retry
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.ok("OK"); // MoMo yêu cầu vẫn phải trả OK
        }
    }

    /**
     * ✅ Return URL cho người dùng redirect lại sau khi thanh toán (trên trình duyệt)
     */
    @GetMapping("/return")
    public ResponseEntity<String> ret(@RequestParam(required = false) String resultCode,
                                      @RequestParam(required = false) String orderId,
                                      @RequestParam(required = false) String amount) {
        long amt = 0;
        try {
            amt = Long.parseLong(amount);
        } catch (Exception ignored) {}

        if ("0".equals(resultCode)) {
            eventPublisher.publishPaymentSuccess(orderId, "MOMO-" + orderId, amt, "MOMO");
            return ResponseEntity.ok("✅ Thanh toán MoMo thành công (Order ID: " + orderId + ")");
        } else {
            String message = switch (resultCode) {
                case "1006" -> "Người dùng hủy giao dịch";
                case "1007" -> "Giao dịch hết hạn";
                case "2007" -> "Sai chữ ký hoặc lỗi hệ thống";
                default -> "Thanh toán MoMo thất bại (code=" + resultCode + ")";
            };

            eventPublisher.publishPaymentFailed(orderId, amt, message, "MOMO");
            return ResponseEntity.ok("❌ " + message);
        }
    }
}
