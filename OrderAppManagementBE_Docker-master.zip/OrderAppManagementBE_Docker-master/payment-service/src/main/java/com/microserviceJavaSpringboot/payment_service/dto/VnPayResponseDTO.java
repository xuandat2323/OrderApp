package com.microserviceJavaSpringboot.payment_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VnPayResponseDTO {
    private String payUrl;       // Link để user redirect sang cổng thanh toán (nếu có)
    private String status;       // PENDING, SUCCESS, FAILED
    private String message;      // Thông báo từ cổng thanh toán
    private String transactionId; // Mã giao dịch (requestId / transactionId từ Momo hoặc VNPay)
}