package com.microserviceJavaSpringboot.payment_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MomoResponseDTO {
    private String payUrl;       // Link để user redirect sang cổng thanh toán (nếu có)
    private String status;       // PENDING, SUCCESS, FAILED
    private String message;      // Thông báo từ cổng thanh toán
    private String transactionId; // Mã giao dịch (requestId / transactionId từ Momo hoặc VNPay)
}