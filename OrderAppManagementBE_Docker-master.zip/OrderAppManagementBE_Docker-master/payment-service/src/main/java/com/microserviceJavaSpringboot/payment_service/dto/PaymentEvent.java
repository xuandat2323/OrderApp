package com.microserviceJavaSpringboot.payment_service.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentEvent {
    private String orderId;
    private String paymentId;
    private long amount;
    private String status;  // PENDING, SUCCESS, FAILED
    private String payUrl;  // optional, để FE redirect
    private String message;
    private String userId;
}