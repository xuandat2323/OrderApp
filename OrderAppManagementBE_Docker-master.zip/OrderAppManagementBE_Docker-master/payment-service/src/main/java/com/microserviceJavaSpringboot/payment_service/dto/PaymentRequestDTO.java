package com.microserviceJavaSpringboot.payment_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentRequestDTO {
    private String orderId;
    private Long amount;
    private String orderInfo;
    private String userId;

    public PaymentRequestDTO(String orderId, String userId, Long amount) {
        this.orderId = orderId;
        this.amount = amount;
        this.userId= userId;
        this.orderInfo = "Thanh toán đơn hàng #" + orderId;
    }
}
