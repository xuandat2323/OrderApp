package com.microserviceJavaSpringboot.payment_service.enums;

public class PaymentStatus {
}
