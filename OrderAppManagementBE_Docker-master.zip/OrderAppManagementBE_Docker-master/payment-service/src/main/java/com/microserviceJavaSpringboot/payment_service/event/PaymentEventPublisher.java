package com.microserviceJavaSpringboot.payment_service.event;

import com.microserviceJavaSpringboot.payment_service.dto.PaymentEvent;
import com.microserviceJavaSpringboot.payment_service.model.PaymentTransaction;
import com.microserviceJavaSpringboot.payment_service.repository.PaymentTransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class PaymentEventPublisher {

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final PaymentTransactionRepository repository;

    private static final String TOPIC = "payment-events";

    public void publishPaymentSuccess(String orderId, String paymentId, long amount, String gateway) {
        PaymentEvent event = PaymentEvent.builder()
                .orderId(orderId)
                .paymentId(paymentId)
                .amount(amount)
                .status("SUCCESS")
                .message("Thanh toán " + gateway + " thành công")
                .userId(findUserIdByOrder(orderId))
                .build();
        kafkaTemplate.send(TOPIC, orderId, event);
        System.out.println("[Kafka] Sent PaymentEvent SUCCESS: " + event);
    }

    public void publishPaymentFailed(String orderId, long amount, String message, String gateway) {
        PaymentEvent event = PaymentEvent.builder()
                .orderId(orderId)
                .amount(amount)
                .status("FAILED")
                .message("Thanh toán " + gateway + " thất bại: " + message)
                .userId(findUserIdByOrder(orderId))
                .build();
        kafkaTemplate.send(TOPIC, orderId, event);
        System.out.println("[Kafka] Sent PaymentEvent FAILED: " + event);
    }

    private String findUserIdByOrder(String orderId) {
        return repository.findByOrderId(orderId)
                .map(PaymentTransaction::getUserId)
                .orElse("unknown");
    }

}
