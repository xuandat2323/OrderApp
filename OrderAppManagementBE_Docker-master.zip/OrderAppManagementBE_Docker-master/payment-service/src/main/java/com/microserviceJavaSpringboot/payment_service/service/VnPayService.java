package com.microserviceJavaSpringboot.payment_service.service;

import com.microserviceJavaSpringboot.payment_service.dto.VnPayResponseDTO;
import com.microserviceJavaSpringboot.payment_service.event.PaymentEventPublisher;
import com.microserviceJavaSpringboot.payment_service.model.PaymentTransaction;
import com.microserviceJavaSpringboot.payment_service.repository.PaymentTransactionRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class VnPayService {

    @Value("${vnpay.tmn-code}")
    private String vnpTmnCode;

    @Value("${vnpay.secret-key}")
    private String secretKey;

    @Value("${vnpay.vnp-url}")
    private String vnpUrl;

    @Value("${vnpay.return-url}")
    private String returnUrl;

    private final PaymentTransactionRepository repository;
    private final PaymentEventPublisher eventPublisher;
    private static final String HMAC_ALGO = "HmacSHA512";

    public VnPayService(PaymentTransactionRepository repository,
                        PaymentEventPublisher eventPublisher) {
        this.repository = repository;
        this.eventPublisher = eventPublisher;
    }

    public VnPayResponseDTO createPaymentUrl(String orderId, String userId, Long amount) throws Exception {
        String vnp_Version = "2.1.0";
        String vnp_Command = "pay";
        String orderType = "billpayment";
        long amountVnd = amount * 100; // VNPAY yêu cầu nhân 100
        String vnp_TxnRef = orderId;

        String vnp_IpAddr = "127.0.0.1";

        Calendar cld = Calendar.getInstance(TimeZone.getTimeZone("Etc/GMT+7"));
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        String vnp_CreateDate = formatter.format(cld.getTime());

        cld.add(Calendar.MINUTE, 15);
        String vnp_ExpireDate = formatter.format(cld.getTime());

        Map<String, String> vnp_Params = new HashMap<>();
        vnp_Params.put("vnp_Version", vnp_Version);
        vnp_Params.put("vnp_Command", vnp_Command);
        vnp_Params.put("vnp_TmnCode", vnpTmnCode);
        vnp_Params.put("vnp_Amount", String.valueOf(amountVnd));
        vnp_Params.put("vnp_CurrCode", "VND");
        vnp_Params.put("vnp_TxnRef", vnp_TxnRef);
        vnp_Params.put("vnp_OrderInfo", "Thanh toan don hang " + orderId);
        vnp_Params.put("vnp_OrderType", orderType);
        vnp_Params.put("vnp_Locale", "vn");
        vnp_Params.put("vnp_ReturnUrl", returnUrl);
        vnp_Params.put("vnp_IpAddr", vnp_IpAddr);
        vnp_Params.put("vnp_CreateDate", vnp_CreateDate);
        vnp_Params.put("vnp_ExpireDate", vnp_ExpireDate);

        List<String> fieldNames = new ArrayList<>(vnp_Params.keySet());
        Collections.sort(fieldNames);

        StringBuilder hashData = new StringBuilder();
        StringBuilder query = new StringBuilder();

        for (Iterator<String> itr = fieldNames.iterator(); itr.hasNext();) {
            String fieldName = itr.next();
            String fieldValue = vnp_Params.get(fieldName);
            if (fieldValue != null && fieldValue.length() > 0) {
                hashData.append(fieldName).append('=').append(fieldValue);
                query.append(URLEncoder.encode(fieldName, StandardCharsets.US_ASCII.toString()))
                        .append('=')
                        .append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII.toString()));
                if (itr.hasNext()) {
                    hashData.append('&');
                    query.append('&');
                }
            }
        }

        String vnp_SecureHash = hmacSHA512(secretKey, hashData.toString());
        query.append("&vnp_SecureHash=").append(vnp_SecureHash);

        String paymentUrl = vnpUrl + "?" + query.toString();

        // Lưu transaction (Pending)
        PaymentTransaction tx = new PaymentTransaction();
        tx.setOrderId(orderId);
        tx.setUserId(userId);
        tx.setAmount(amount);
        tx.setStatus("PENDING");
        tx.setCreatedAt(LocalDateTime.now());
        tx.setPayUrl(paymentUrl);
        repository.save(tx);

        return VnPayResponseDTO.builder()
                .payUrl(paymentUrl)
                .status("PENDING")
                .message("Tạo yêu cầu thanh toán VNPay thành công")
                .transactionId(vnp_TxnRef)
                .build();
    }

    public void handleIpn(Map<String, String> params) {
        System.out.println("VNPay IPN received: " + params);

        if (!validateVnPaySignature(new HashMap<>(params), secretKey)) {
            System.err.println("INVALID_SIGNATURE - VNPay IPN bị sai chữ ký!");
            eventPublisher.publishPaymentFailed(
                    params.get("vnp_TxnRef"),
                    Long.parseLong(params.get("vnp_Amount")) / 100,
                    "Sai chữ ký VNPay",
                    "VNPAY"
            );
            return;
        }

        String orderId = params.get("vnp_TxnRef");
        String responseCode = params.get("vnp_ResponseCode");
        long amount = Long.parseLong(params.get("vnp_Amount")) / 100;

        PaymentTransaction tx = repository.findByOrderId(orderId).orElse(null);
        if (tx != null) {
            tx.setStatus("00".equals(responseCode) ? "SUCCESS" : "FAILED");
            tx.setUpdatedAt(LocalDateTime.now());
            repository.save(tx);
        }

        if ("00".equals(responseCode)) {
            eventPublisher.publishPaymentSuccess(orderId, "VNPAY-" + orderId, amount, "VNPAY");
        } else {
            String message = switch (responseCode) {
                case "24" -> "Người dùng hủy giao dịch";
                case "51" -> "Không đủ số dư tài khoản";
                case "99" -> "Lỗi không xác định";
                default -> "VNPay thất bại (code = " + responseCode + ")";
            };
            eventPublisher.publishPaymentFailed(orderId, amount, message, "VNPAY");
        }
    }


    private String hmacSHA512(String key, String data) {
        try {
            Mac hmac512 = Mac.getInstance("HmacSHA512");
            SecretKeySpec secretKeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA512");
            hmac512.init(secretKeySpec);
            byte[] result = hmac512.doFinal(data.getBytes(StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder(2 * result.length);
            for (byte b : result) {
                sb.append(String.format("%02x", b & 0xff));
            }
            return sb.toString();
        } catch (Exception ex) {
            throw new RuntimeException("Lỗi tạo HmacSHA512", ex);
        }
    }

    private boolean validateVnPaySignature(Map<String, String> params, String secretKey) {
        try {
            // Lấy chữ ký từ VNPay gửi đến
            String vnp_SecureHash = params.get("vnp_SecureHash");
            params.remove("vnp_SecureHash");
            params.remove("vnp_SecureHashType");

            // Sort theo key
            List<String> fieldNames = new ArrayList<>(params.keySet());
            Collections.sort(fieldNames);

            StringBuilder hashData = new StringBuilder();
            for (Iterator<String> itr = fieldNames.iterator(); itr.hasNext();) {
                String fieldName = itr.next();
                String fieldValue = params.get(fieldName);
                if (fieldValue != null && fieldValue.length() > 0) {
                    hashData.append(fieldName).append('=').append(fieldValue);
                    if (itr.hasNext()) hashData.append('&');
                }
            }

            // Tạo chữ ký của bạn để so sánh
            Mac hmac512 = Mac.getInstance(HMAC_ALGO);
            SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), HMAC_ALGO);
            hmac512.init(secretKeySpec);
            byte[] result = hmac512.doFinal(hashData.toString().getBytes(StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder(2 * result.length);
            for (byte b : result) sb.append(String.format("%02x", b & 0xff));
            String computedHash = sb.toString();

            return computedHash.equalsIgnoreCase(vnp_SecureHash);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private PaymentTransaction saveTransaction(String orderId, String requestId, long amount, String status) {
        PaymentTransaction tx = new PaymentTransaction();
        tx.setOrderId(orderId);
        tx.setRequestId(requestId);
        tx.setAmount(amount);
        tx.setStatus(status);
        tx.setCreatedAt(LocalDateTime.now());
        return repository.save(tx);
    }

    public void simulateVnPay(String orderId, long amount, String userId, boolean success) {
        System.out.println("Simulating VNPay payment for orderId=" + orderId + ", userId=" + userId + ", success=" + success);

        //Tìm transaction đã tạo hoặc khởi tạo mới
        PaymentTransaction tx = repository.findByOrderId(orderId).orElse(null);
        if (tx == null) {
            tx = new PaymentTransaction();
            tx.setOrderId(orderId);
            tx.setAmount(amount);
            tx.setUserId(userId);
            tx.setCreatedAt(LocalDateTime.now());
        }

        //Cập nhật trạng thái giao dịch
        tx.setStatus(success ? "SUCCESS" : "FAILED");
        tx.setUpdatedAt(LocalDateTime.now());
        repository.save(tx);

        //Phát sự kiện Kafka
        if (success) {
            eventPublisher.publishPaymentSuccess(orderId, "VNPAY-" + orderId, amount, "VNPAY");
            System.out.println("[Simulated] Payment success event sent for order " + orderId);
        } else {
            eventPublisher.publishPaymentFailed(orderId, amount, "Giả lập thanh toán thất bại", "VNPAY");
            System.out.println("[Simulated] Payment failed event sent for order " + orderId);
        }
    }

}
