package com.microserviceJavaSpringboot.invoice_service.controller;

import com.microserviceJavaSpringboot.invoice_service.model.Invoice;
import com.microserviceJavaSpringboot.invoice_service.service.InvoiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    /**
     * Tìm kiếm, lọc, sắp xếp, phân trang
     *
     * Ví dụ:
     * GET /api/invoices?keyword=123&method=MOMO&status=CREATED&sortBy=createdAt&direction=DESC&page=0&size=10
     */
    @GetMapping
    public ResponseEntity<Page<Invoice>> searchInvoices(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String method,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Page<Invoice> result = invoiceService.searchInvoices(keyword, method, status, sortBy, direction, page, size);
        return ResponseEntity.ok(result);
    }

    /**
     * Lấy chi tiết hóa đơn theo orderId
     */
    @GetMapping("/{orderId}")
    public ResponseEntity<Invoice> getInvoiceByOrderId(@PathVariable String orderId) {
        Invoice invoice = invoiceService.getInvoiceByOrderId(orderId);
        return ResponseEntity.ok(invoice);
    }

    /**
     * Tải file PDF hóa đơn
     *
     * Ví dụ: GET /api/invoices/123/pdf
     */
    @GetMapping("/{orderId}/pdf")
    public ResponseEntity<FileSystemResource> downloadInvoicePdf(@PathVariable String orderId) {
        Invoice invoice = invoiceService.getInvoiceByOrderId(orderId);
        File file = new File(invoice.getPdfPath());

        if (!file.exists()) {
            return ResponseEntity.notFound().build();
        }

        FileSystemResource resource = new FileSystemResource(file);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName())
                .contentType(MediaType.APPLICATION_PDF)
                .body(resource);
    }
}
