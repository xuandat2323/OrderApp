package com.microserviceJavaSpringboot.invoice_service.service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;
import com.microserviceJavaSpringboot.invoice_service.model.Invoice;
import com.microserviceJavaSpringboot.invoice_service.repository.InvoiceRepository;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final InvoiceRepository repository;

    @Value("${invoice.storage-path}")
    private String invoiceStoragePath;

    //Phương thức tạo hóa đơn (gọi khi payment thành công)
    public Invoice createInvoice(String orderId, String paymentId, Long amount, String method) {
        try {
            Invoice invoice = Invoice.builder()
                    .orderId(orderId)
                    .paymentId(paymentId)
                    .method(method)
                    .amount(amount)
                    .status("CREATED")
                    .createdAt(LocalDateTime.now())
                    .build();

            // Tạo file PDF
            String pdfPath = generateInvoicePDF(invoice);
            invoice.setPdfPath(pdfPath);

            return repository.save(invoice);
        } catch (Exception e) {
            throw new RuntimeException("Không thể tạo hóa đơn cho orderId=" + orderId, e);
        }
    }

    //Sinh file PDF hóa đơn
    private String generateInvoicePDF(Invoice invoice) throws Exception {
        // Đảm bảo thư mục tồn tại
        Path directoryPath = Paths.get(invoiceStoragePath);
        Files.createDirectories(directoryPath);

        // Đường dẫn file PDF
        String fileName = "invoice_" + invoice.getOrderId() + ".pdf";
        Path pdfFilePath = directoryPath.resolve(fileName);

        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(pdfFilePath.toFile()));
        document.open();

        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
        Font textFont = FontFactory.getFont(FontFactory.HELVETICA, 12);

        document.add(new Paragraph("HÓA ĐƠN THANH TOÁN", titleFont));
        document.add(new Paragraph(" "));
        document.add(new Paragraph("Mã đơn hàng: " + invoice.getOrderId(), textFont));
        document.add(new Paragraph("Mã thanh toán: " + invoice.getPaymentId(), textFont));
        document.add(new Paragraph("Phương thức: " + invoice.getMethod(), textFont));
        document.add(new Paragraph("Số tiền: " + invoice.getAmount() + " VND", textFont));
        document.add(new Paragraph("Ngày tạo: " + invoice.getCreatedAt(), textFont));

        document.close();

        System.out.println("📦 Hóa đơn được lưu tại: " + pdfFilePath);
        return pdfFilePath.toAbsolutePath().toString();
    }

    //Tìm kiếm, lọc, phân trang
    public Page<Invoice> searchInvoices(
            String keyword,
            String method,
            String status,
            String sortBy,
            String direction,
            int page,
            int size
    ) {
        Specification<Invoice> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (keyword != null && !keyword.isEmpty()) {
                Predicate orderIdMatch = cb.like(root.get("orderId"), "%" + keyword + "%");
                Predicate paymentIdMatch = cb.like(root.get("paymentId"), "%" + keyword + "%");
                predicates.add(cb.or(orderIdMatch, paymentIdMatch));
            }

            if (method != null && !method.isEmpty()) {
                predicates.add(cb.equal(root.get("method"), method));
            }

            if (status != null && !status.isEmpty()) {
                predicates.add(cb.equal(root.get("status"), status));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };

        Sort.Direction sortDirection;
        try {
            sortDirection = Sort.Direction.fromString(direction);
        } catch (Exception e) {
            sortDirection = Sort.Direction.DESC;
        }

        Sort sort = Sort.by(sortDirection, sortBy != null ? sortBy : "createdAt");
        Pageable pageable = PageRequest.of(page, size, sort);

        return repository.findAll(spec, pageable);
    }

    //Lấy hóa đơn theo mã đơn hàng
    public Invoice getInvoiceByOrderId(String orderId) {
        return repository.findByOrderId(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy hóa đơn cho orderId=" + orderId));
    }
}
