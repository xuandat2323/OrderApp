package com.microserviceJavaSpringboot.invoice_service.kafka;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microserviceJavaSpringboot.invoice_service.model.Invoice;
import com.microserviceJavaSpringboot.invoice_service.service.InvoiceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentEventConsumer {

    private final InvoiceService invoiceService;
    private final InvoiceEventPublisher invoiceEventPublisher;
    private final ObjectMapper mapper = new ObjectMapper();

    @KafkaListener(topics = "payment-events", groupId = "invoice-service-group")
    public void handlePaymentEvent(String message) {
        try {
            JsonNode json = mapper.readTree(message);

            String orderId = json.get("orderId").asText();
            String status = json.get("status").asText();
            String paymentId = json.has("paymentId") ? json.get("paymentId").asText() : "UNKNOWN";
            long amount = json.has("amount") ? json.get("amount").asLong() : 0;
            String msg = json.has("message") ? json.get("message").asText() : "";
            String gateway = detectGateway(paymentId);

            log.info("📥 Nhận PaymentEvent: orderId={}, status={}, gateway={}", orderId, status, gateway);

            // ✅ Nếu thanh toán thành công → tạo hóa đơn
            if ("SUCCESS".equalsIgnoreCase(status)) {
                Invoice invoice = invoiceService.createInvoice(orderId, paymentId, amount, gateway);
                invoiceEventPublisher.publishInvoiceCreated(orderId, invoice.getId(), invoice.getPdfPath());
                log.info("🧾 Hóa đơn được tạo cho orderId={}, file={}", orderId, invoice.getPdfPath());
            }
            // ❌ Nếu thanh toán thất bại → có thể ghi log hoặc gửi event riêng
            else if ("FAILED".equalsIgnoreCase(status)) {
                log.warn("⚠️ Thanh toán thất bại cho orderId={} ({}) — không tạo hóa đơn", orderId, msg);
            }

        } catch (Exception e) {
            log.error("❌ Lỗi khi xử lý event Kafka (payment-events): {}", e.getMessage(), e);
        }
    }



    private String detectGateway(String paymentId) {
        if (paymentId == null || paymentId.isBlank()) return "UNKNOWN";
        if (paymentId.startsWith("MOMO")) return "MOMO";
        if (paymentId.startsWith("VNPAY")) return "VNPAY";
        return "OTHER";
    }
}
