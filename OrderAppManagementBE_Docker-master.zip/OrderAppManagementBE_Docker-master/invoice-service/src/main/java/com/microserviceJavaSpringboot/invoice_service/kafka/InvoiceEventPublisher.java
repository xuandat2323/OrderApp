package com.microserviceJavaSpringboot.invoice_service.kafka;

import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class InvoiceEventPublisher {

    private final KafkaTemplate<String, String> kafkaTemplate;

    public void publishInvoiceCreated(String orderId, Long invoiceId, String pdfPath) {
        String event = String.format("""
            {
              "orderId": "%s",
              "invoiceId": %d,
              "pdfPath": "%s",
              "status": "CREATED"
            }
        """, orderId, invoiceId, pdfPath);

        kafkaTemplate.send("invoice-created-topic", event);
    }
}